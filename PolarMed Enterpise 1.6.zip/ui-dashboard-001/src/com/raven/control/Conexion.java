/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.raven.control;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;

/**
 *
 * @author xaldo
 */
public class Conexion {
    MongoClient mongo=null;
   String mongoLocal = "mongodb://localhost:27017";
   String mongoNube = "";
    //Método para obtener una instancia de la conexión
    public MongoClient obtenerConexion() {
        try {
            mongo=MongoClients.create(mongoLocal);
            System.out.println("Conectado a Mongo");
            return mongo;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    //Método para cerrar la conexión
    public void cerrarConexion() {
        if(mongo==null){
            mongo.close();
        }
    }
}
