package com.raven.form;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import static com.mongodb.client.model.Filters.eq;
import com.mongodb.client.result.DeleteResult;
import com.raven.control.Conexion;
import javax.swing.JOptionPane;
import com.raven.form.Form_5;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;

public class Form_7 extends javax.swing.JPanel {

    Conexion con = new Conexion();
    MongoClient mongo = con.obtenerConexion();
    MongoDatabase base = mongo.getDatabase("SSCL");

    public Form_7() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        editarBtn = new javax.swing.JButton();
        eliminarBtn = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("Lista de Pacientes");

        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Nombre", "Apellido", "Nombre Representante", "Celular"
            }
        ));
        jScrollPane1.setViewportView(table);

        editarBtn.setText("EDITAR");
        editarBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editarBtnActionPerformed(evt);
            }
        });

        eliminarBtn.setText("ELIMINAR");
        eliminarBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminarBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(311, 311, 311)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(181, 181, 181)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(292, 292, 292)
                        .addComponent(editarBtn)
                        .addGap(57, 57, 57)
                        .addComponent(eliminarBtn)))
                .addContainerGap(220, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(editarBtn)
                    .addComponent(eliminarBtn))
                .addContainerGap(11, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void editarBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editarBtnActionPerformed
       // Obtener el índice de la fila seleccionada
    int filaSeleccionada = table.getSelectedRow();
    if (filaSeleccionada == -1) {
        JOptionPane.showMessageDialog(this, "Por favor, seleccione un paciente para editar.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Verificar si la tabla tiene suficientes columnas
    if (table.getColumnCount() < 4) {
        JOptionPane.showMessageDialog(this, "La tabla no tiene suficientes columnas para editar el paciente.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Obtener los datos del paciente seleccionado
    String nombrePaciente = (String) table.getValueAt(filaSeleccionada, 0);
    String apellidoPaciente = (String) table.getValueAt(filaSeleccionada, 1);
    String nombreRepresentante = (String) table.getValueAt(filaSeleccionada, 2);
    String numeroTelefonico = (String) table.getValueAt(filaSeleccionada, 3);

    // Mostrar cuadros de diálogo para que el usuario ingrese los nuevos datos
    String nuevoNombrePaciente = JOptionPane.showInputDialog(this, "Ingrese el nuevo nombre para el paciente:", nombrePaciente);
    String nuevoApellidoPaciente = JOptionPane.showInputDialog(this, "Ingrese el nuevo apellido para el paciente:", apellidoPaciente);
    String nuevoNombreRepresentante = JOptionPane.showInputDialog(this, "Ingrese el nuevo nombre del representante para el paciente:", nombreRepresentante);
    String nuevoNumeroTelefonico = JOptionPane.showInputDialog(this, "Ingrese el nuevo número telefónico para el paciente:", numeroTelefonico);

    // Verificar si se canceló la edición o si algún campo está vacío
    if (nuevoNombrePaciente == null || nuevoNombrePaciente.isEmpty() || nuevoApellidoPaciente == null || nuevoApellidoPaciente.isEmpty()
            || nuevoNombreRepresentante == null || nuevoNombreRepresentante.isEmpty() || nuevoNumeroTelefonico == null || nuevoNumeroTelefonico.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios y no pueden estar vacíos.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Actualizar los datos del paciente en la tabla
    table.setValueAt(nuevoNombrePaciente, filaSeleccionada, 0);
    table.setValueAt(nuevoApellidoPaciente, filaSeleccionada, 1);
    table.setValueAt(nuevoNombreRepresentante, filaSeleccionada, 2);
    table.setValueAt(nuevoNumeroTelefonico, filaSeleccionada, 3);

    // Actualizar los datos del paciente en la base de datos
    MongoCollection<Document> coleccion = base.getCollection("Pacientes");
    Document filtro = new Document("pac_nombre", nombrePaciente); // Ajusta el campo de filtro según tu estructura de datos
    Document actualizacion = new Document("$set", new Document("pac_nombre", nuevoNombrePaciente)
            .append("pac_apellido", nuevoApellidoPaciente)
            .append("rep_nombre", nuevoNombreRepresentante)
            .append("con_numcel", nuevoNumeroTelefonico));
    coleccion.updateOne(filtro, actualizacion);

    JOptionPane.showMessageDialog(this, "Datos del paciente actualizados correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);

    
    }//GEN-LAST:event_editarBtnActionPerformed

    private void eliminarBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminarBtnActionPerformed

        int filaSeleccionada = table.getSelectedRow();
        if (filaSeleccionada != -1) {
            String nombrePaciente = (String) table.getValueAt(filaSeleccionada, 0);
            boolean eliminado = eliminarPaciente(nombrePaciente);
            if (eliminado) {
                JOptionPane.showMessageDialog(this, "Paciente eliminado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                fillTableWithData(); // Actualizar la tabla después de eliminar
            } else {
                JOptionPane.showMessageDialog(this, "Error al eliminar el paciente.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Seleccione un paciente para eliminar.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        
        fillTableWithData(); // Actualizar la tabla con los datos actuales de la base de datos
    }//GEN-LAST:event_eliminarBtnActionPerformed

    // Método para eliminar un paciente por nombre
    private boolean eliminarPaciente(String nombre) {
        MongoCollection<Document> coleccion = base.getCollection("Pacients");
        DeleteResult result = coleccion.deleteOne(eq("pac_nombre", nombre));
        return result.getDeletedCount() > 0;
    }

    // Método para llenar la tabla con datos de la base de datos
    private void fillTableWithData() {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0); // Limpiar la tabla antes de volver a llenar
        MongoCollection<Document> coleccion = base.getCollection("Pacients");
        MongoCursor<Document> cursor = coleccion.find().iterator();
        while (cursor.hasNext()) {
            Document dato = cursor.next();
            String nombre = dato.getString("pac_nombre");
            String apellido = dato.getString("pac_apellido");
            String representante = dato.getString("rep_nombre");
            String contacto = dato.getString("con_numcel");
            model.addRow(new Object[]{nombre, apellido, representante, contacto});
        }
        cursor.close();
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton editarBtn;
    private javax.swing.JButton eliminarBtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable table;
    // End of variables declaration//GEN-END:variables
}
