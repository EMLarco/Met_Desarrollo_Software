package com.raven.form;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import static com.mongodb.client.model.Filters.eq;
import com.raven.control.Conexion;
import com.raven.model.EditarProveedorForm;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;


public class Form_4 extends javax.swing.JPanel {

    Conexion con = new Conexion();
    MongoClient mongo = con.obtenerConexion();
    MongoDatabase base = mongo.getDatabase("SSCL");

    public Form_4() {
        initComponents();

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();
        editarBtn = new javax.swing.JButton();
        eliminarBtn = new javax.swing.JButton();
        actualizarBtn = new javax.swing.JButton();

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("Lista De Proveedores");

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Nombre", "Direccion", "Telefono", "Email", "Tipo de Producto", "Sitio Web"
            }
        ));
        jScrollPane1.setViewportView(tabla);

        editarBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        editarBtn.setText("EDITAR");
        editarBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editarBtnActionPerformed(evt);
            }
        });

        eliminarBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        eliminarBtn.setText("ELIMINAR");
        eliminarBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminarBtnActionPerformed(evt);
            }
        });

        actualizarBtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        actualizarBtn.setText("ACTUALIZAR");
        actualizarBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                actualizarBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(251, 251, 251)
                        .addComponent(editarBtn)
                        .addGap(18, 18, 18)
                        .addComponent(eliminarBtn)
                        .addGap(26, 26, 26)
                        .addComponent(actualizarBtn))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(311, 311, 311)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(181, 181, 181)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 439, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(214, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(editarBtn)
                    .addComponent(eliminarBtn)
                    .addComponent(actualizarBtn))
                .addContainerGap(26, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void editarBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editarBtnActionPerformed
        editarProveedor();
    }//GEN-LAST:event_editarBtnActionPerformed

    private void eliminarBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminarBtnActionPerformed
        eliminarProveedor();
    }//GEN-LAST:event_eliminarBtnActionPerformed

    private void actualizarBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_actualizarBtnActionPerformed
        actualizarCambios();
    }//GEN-LAST:event_actualizarBtnActionPerformed

    private void cargarDatosProveedor() {
        DefaultTableModel model = (DefaultTableModel) tabla.getModel();
        MongoCollection coleccion = base.getCollection("Proveedores");
        MongoCursor<Document> cursor = coleccion.find().cursor();
        while (cursor.hasNext()) {
            Document dato = cursor.next();
            String nombre = dato.getString("nombre");
            String direccion = dato.getString("direccion");
            String telefono = dato.getString("telefono");
            String email = dato.getString("email");
            String tipoProducto = dato.getString("tipo_producto");
            String sitioWeb = dato.getString("sitio_web");

            // Agregar fila a la tabla
            model.addRow(new Object[]{nombre, direccion, telefono, email, tipoProducto, sitioWeb});
        }
    }

    private void editarProveedor() {
       // Obtener el índice de la fila seleccionada
    int filaSeleccionada = tabla.getSelectedRow();
    if (filaSeleccionada == -1) {
        JOptionPane.showMessageDialog(this, "Por favor, seleccione un proveedor para editar.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Verificar si la tabla tiene suficientes columnas
    if (tabla.getColumnCount() < 6) {
        JOptionPane.showMessageDialog(this, "La tabla no tiene suficientes columnas para editar el proveedor.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    // Obtener los datos del proveedor seleccionado
    String nombreProveedor = (String) tabla.getValueAt(filaSeleccionada, 0);
    String direccionProveedor = (String) tabla.getValueAt(filaSeleccionada, 1);
    String telefonoProveedor = (String) tabla.getValueAt(filaSeleccionada, 2);
    String emailProveedor = (String) tabla.getValueAt(filaSeleccionada, 3);
    String tipoProductoProveedor = (String) tabla.getValueAt(filaSeleccionada, 4);
    String sitioWebProveedor = (String) tabla.getValueAt(filaSeleccionada, 5);

        // Mostrar cuadros de diálogo para que el usuario ingrese los nuevos datos
        String nuevoNombre = JOptionPane.showInputDialog(this, "Ingrese el nuevo nombre para el proveedor:", nombreProveedor);
        String nuevaDireccion = JOptionPane.showInputDialog(this, "Ingrese la nueva dirección para el proveedor:", direccionProveedor);
        String nuevoTelefono = JOptionPane.showInputDialog(this, "Ingrese el nuevo teléfono para el proveedor:", telefonoProveedor);
        String nuevoEmail = JOptionPane.showInputDialog(this, "Ingrese el nuevo email para el proveedor:", emailProveedor);
        String nuevoTipoProducto = JOptionPane.showInputDialog(this, "Ingrese el nuevo tipo de producto para el proveedor:", tipoProductoProveedor);
        String nuevoSitioWeb = JOptionPane.showInputDialog(this, "Ingrese el nuevo sitio web para el proveedor:", sitioWebProveedor);

        // Verificar si se canceló la edición o si algún campo está vacío
        if (nuevoNombre == null || nuevoNombre.isEmpty() || nuevaDireccion == null || nuevaDireccion.isEmpty() || nuevoTelefono == null || nuevoTelefono.isEmpty()
                || nuevoEmail == null || nuevoEmail.isEmpty() || nuevoTipoProducto == null || nuevoTipoProducto.isEmpty() || nuevoSitioWeb == null || nuevoSitioWeb.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios y no pueden estar vacíos.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Actualizar los datos del proveedor en la base de datos
        MongoCollection<Document> coleccion = base.getCollection("Proveedores");
        Document filtro = new Document("nombre", nombreProveedor);
        Document actualizacion = new Document("$set", new Document("nombre", nuevoNombre)
                .append("direccion", nuevaDireccion)
                .append("telefono", nuevoTelefono)
                .append("email", nuevoEmail)
                .append("tipo_producto", nuevoTipoProducto)
                .append("sitio_web", nuevoSitioWeb));
        coleccion.updateOne(filtro, actualizacion);

        // Limpiar la tabla antes de cargar los datos actualizados
        DefaultTableModel model = (DefaultTableModel) tabla.getModel();
        model.setRowCount(0);

        // Actualizar la tabla para reflejar los cambios
        cargarDatosProveedor();

    }

    private void eliminarProveedor() {
        // Obtener el índice de la fila seleccionada
        int filaSeleccionada = tabla.getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(this, "Por favor, seleccione un proveedor para eliminar.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Obtener el nombre del proveedor seleccionado
        String nombreProveedor = (String) tabla.getValueAt(filaSeleccionada, 0);

        // Confirmar la eliminación con un cuadro de diálogo
        int opcion = JOptionPane.showConfirmDialog(this, "¿Está seguro de que desea eliminar al proveedor " + nombreProveedor + "?", "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
        if (opcion == JOptionPane.YES_OPTION) {
            // Eliminar el proveedor de la base de datos MongoDB
            MongoCollection coleccion = base.getCollection("Proveedores");
            coleccion.deleteOne(eq("nombre", nombreProveedor)); // Suponiendo que el campo de nombre sea único
            JOptionPane.showMessageDialog(this, "Proveedor eliminado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            // Volver a cargar los datos en la tabla después de la eliminación
            cargarDatosProveedor();
        }
    }

    private void actualizarCambios() {
        // Obtener la referencia a la tabla desde tu panel
        DefaultTableModel model = (DefaultTableModel) tabla.getModel();
        // Limpiar el modelo antes de agregar nuevos datos
        model.setRowCount(0);

        MongoCollection<Document> coleccion = base.getCollection("Proveedores");
        MongoCursor<Document> cursor = coleccion.find().iterator(); // Usar iterator() en lugar de cursor()

        try {
            while (cursor.hasNext()) {
                Document dato = cursor.next();
                String nombre = dato.getString("nombre");
                String direccion = dato.getString("direccion");
                String telefono = dato.getString("telefono");
                String email = dato.getString("email");
                String tipoProducto = dato.getString("tipo_producto");
                String sitioWeb = dato.getString("sitio_web");

                // Agregar fila a la tabla
                model.addRow(new Object[]{nombre, direccion, telefono, email, tipoProducto, sitioWeb});
            }
        } finally {
            cursor.close(); // Cerrar el cursor después de usarlo
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton actualizarBtn;
    private javax.swing.JButton editarBtn;
    private javax.swing.JButton eliminarBtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tabla;
    // End of variables declaration//GEN-END:variables
}
