package com.raven.form;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.raven.control.Conexion;
import com.raven.model.Model_Card;
import com.raven.model.StatusType;
import com.raven.swing.ScrollBar;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import org.bson.Document;
import com.raven.form.Form_5;

public class Form_Home extends javax.swing.JPanel {

    Conexion con = new Conexion();
    MongoClient mongo = con.obtenerConexion();
    MongoDatabase base = mongo.getDatabase("SSCL");

    private JTextField nombrePacienteField;
    private JTextField segundoNombreField;
    private JTextField apellidoPacienteField;
    private JTextField nombreRepresentanteField;
    private JTextField apellidoRepresentanteField;
    private JTextField parentezcoField;
    private JTextField codigoAreaField;
    private JTextField numeroTelefonicoField;
    private JTextField direccionCalleField;
    private JTextField direccionCalle2Field;
    private JTextField ciudadField;
    private JTextField estadoField;
    private JTextField paisField;

    public Form_Home() {
        initComponents();
        card1.setData(new Model_Card(new ImageIcon(getClass().getResource("/com/raven/icon/stock.png")), "", "BIENVENIDO", ""));

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        panel = new javax.swing.JLayeredPane();
        card1 = new com.raven.component.Card();
        card2 = new com.raven.component.Card();
        card3 = new com.raven.component.Card();

        jLabel1.setText("jLabel1");

        setBackground(new java.awt.Color(255, 255, 255));

        panel.setLayout(new java.awt.GridLayout(1, 0, 10, 0));

        card1.setColor1(new java.awt.Color(0, 153, 255));
        card1.setColor2(new java.awt.Color(123, 123, 245));
        panel.add(card1);

        card2.setColor1(new java.awt.Color(186, 123, 247));
        card2.setColor2(new java.awt.Color(167, 94, 236));
        panel.add(card2);

        card3.setColor1(new java.awt.Color(241, 208, 62));
        card3.setColor2(new java.awt.Color(211, 184, 61));
        panel.add(card3);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(panel, javax.swing.GroupLayout.DEFAULT_SIZE, 875, Short.MAX_VALUE)
                .addGap(20, 20, 20))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(456, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void guardarPaciente() {
        String nombrePaciente = nombrePacienteField.getText();
        String segundoNombre = segundoNombreField.getText();
        String apellidoPaciente = apellidoPacienteField.getText();
        String nombreRepresentante = nombreRepresentanteField.getText();
        String apellidoRepresentante = apellidoRepresentanteField.getText();
        String parentezco = parentezcoField.getText();
        String codigoArea = codigoAreaField.getText();
        String numeroTelefonico = numeroTelefonicoField.getText();
        String direccionCalle = direccionCalleField.getText();
        String direccionCalle2 = direccionCalle2Field.getText();
        String ciudad = ciudadField.getText();
        String estado = estadoField.getText();
        String pais = paisField.getText();

        // Realizar la inserción en la base de datos
        MongoCollection<Document> coleccion = base.getCollection("Pacients");
        Document insertar = new Document();
        insertar.append("pac_nombre", nombrePaciente)
                .append("pac_donombre", segundoNombre)
                .append("pac_apellido", apellidoPaciente)
                .append("rep_nombre", nombreRepresentante)
                .append("rep_apellido", apellidoRepresentante)
                .append("rep_parentezco", parentezco)
                .append("con_numcel", numeroTelefonico)
                .append("con_codearea", codigoArea)
                .append("res_dire1", direccionCalle)
                .append("res_dire2", direccionCalle2)
                .append("res_ciu", ciudad)
                .append("res_prov", estado)
                .append("res_pais", pais);
        coleccion.insertOne(insertar);
        JOptionPane.showMessageDialog(null, "Datos guardados correctamente en la base de datos.");

        
    }

    


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.raven.component.Card card1;
    private com.raven.component.Card card2;
    private com.raven.component.Card card3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLayeredPane panel;
    // End of variables declaration//GEN-END:variables
}
