
package com.raven.form;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.raven.control.Conexion;
import com.raven.component.Header;
import java.awt.BorderLayout;
import java.awt.Color;
import java.util.ArrayList;
import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import org.bson.Document;

public class Form_6 extends javax.swing.JPanel {

  
    Conexion con = new Conexion();
    MongoClient mongo = con.obtenerConexion();
    MongoDatabase base = mongo.getDatabase("SSCL");
    public Form_6() {
        initComponents();
        
       
     
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        buscarField = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        resultadosList = new javax.swing.JList<>();
        guardarBtn = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("Busqueda Paciente");

        jScrollPane1.setViewportView(resultadosList);

        guardarBtn.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        guardarBtn.setText("BUSCAR");
        guardarBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                guardarBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(296, 296, 296)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(133, 133, 133)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(buscarField)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 548, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(327, 327, 327)
                        .addComponent(guardarBtn)))
                .addContainerGap(95, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(63, 63, 63)
                .addComponent(jLabel1)
                .addGap(42, 42, 42)
                .addComponent(buscarField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(guardarBtn)
                .addContainerGap(133, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void guardarBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_guardarBtnActionPerformed
        actualizarResultados();
    }//GEN-LAST:event_guardarBtnActionPerformed

    // Método para actualizar los resultados de búsqueda
    private void actualizarResultados() {
        String nombre = buscarField.getText().trim();

        // Realizar la búsqueda en la base de datos y obtener los resultados
        ArrayList<String> resultados = buscarPacientesPorNombre(nombre);

        // Actualizar la lista de resultados en la interfaz gráfica
        DefaultListModel listModel = new DefaultListModel();
        for (String resultado : resultados) {
            listModel.addElement(resultado);
        }
        resultadosList.setModel(listModel);
        
        resultadosList.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    // Obtener el paciente seleccionado
                    String pacienteSeleccionado = resultadosList.getSelectedValue();

                    if (pacienteSeleccionado != null) {
                        // Mostrar la ventana de detalles del paciente
                        mostrarDetallesPaciente(pacienteSeleccionado);
                    }
                }
            }
        });
    }

    // Método para buscar pacientes por nombre en la base de datos
   public ArrayList<String> buscarPacientesPorNombre(String nombre) {
        ArrayList<String> resultados = new ArrayList<>();
        
        MongoCollection coleccion = base.getCollection("Pacients");
        Document regex = new Document("pac_nombre",new Document("$regex",nombre));
        try{
            MongoCursor<Document> cursor = coleccion.find(regex).iterator();
            while(cursor.hasNext()){
                Document dato = cursor.next();
                String nombrePaciente = dato.getString("pac_nombre");
                resultados.add(nombrePaciente);
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(this, "Error al buscar pacientes: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return resultados;
    }

    // Método para mostrar los detalles de un paciente
    private void mostrarDetallesPaciente(String nombrePaciente) {
        // Crear una nueva ventana o diálogo para mostrar los detalles del paciente
        JFrame detallesFrame = new JFrame("Detalles del Paciente");
        detallesFrame.setSize(400, 300);
        detallesFrame.setAlwaysOnTop(true);
        detallesFrame.setLocationRelativeTo(null);
        detallesFrame.setResizable(false);
        

        // Establecer el color de fondo en #203B49
        detallesFrame.getContentPane().setBackground(Color.decode("#203B49"));

        JPanel detallesPanel = new JPanel(new BorderLayout());
        detallesPanel.setBackground(Color.decode("#203B49"));

        // Obtener y mostrar los detalles del paciente desde la base de datos
        JTextArea detallesTextArea = new JTextArea();
        detallesTextArea.setBackground(Color.decode("#203B49")); // Fondo gris claro
        detallesTextArea.setForeground(Color.WHITE); // Color de letra blanco

        // Realizar la consulta para obtener los detalles del paciente por nombre
        String detalles = obtenerDetallesPaciente(nombrePaciente);

        // Establecer los detalles en el área de texto
        detallesTextArea.setText(detalles);

        detallesPanel.add(new JScrollPane(detallesTextArea), BorderLayout.CENTER);
        detallesFrame.setContentPane(detallesPanel);
        detallesFrame.setVisible(true);
    }

    // Método para obtener los detalles del paciente desde la base de datos
    private String obtenerDetallesPaciente(String nombrePacienteField) {
        String detalles = "";
        MongoCollection coleccion = base.getCollection("Pacients");
        MongoCursor<Document> cursor = coleccion.find(new Document("pac_nombre",nombrePacienteField)).cursor();
        try{
            Document dato = cursor.next();
            detalles += "Nombre: " + dato.getString("pac_nombre") + "\n";
            detalles += "Segundo Nombre: " + dato.getString("pac_donombre") + "\n";
            detalles += "Apellido: " + dato.getString("pac_apellido") + "\n";
            detalles += "Nombre del Representante: " + dato.getString("rep_nombre") + "\n";
            detalles += "Apellido del Representante: " + dato.getString("rep_apellido") + "\n";
            detalles += "Parentezco: " + dato.getString("rep_parentezco") + "\n";
            detalles += "Numero Telefonico: " + dato.getString("con_numcel") + "\n";
            detalles += "Codigo de Area: " + dato.getString("con_codearea") + "\n";
            detalles += "Dirección de la calle: " + dato.getString("res_dire1") + "\n";
            detalles += "Dirección de la calla 2: " + dato.getString("res_dire2") + "\n";
            detalles += "Ciudad: " + dato.getString("res_ciu") + "\n";
            detalles += "Provincia: " + dato.getString("res_prov") + "\n";
            detalles += "Pais: " + dato.getString("res_pais") + "\n";
        }catch(Exception e){
        }
        return detalles;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField buscarField;
    private javax.swing.JButton guardarBtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JList<String> resultadosList;
    // End of variables declaration//GEN-END:variables
}
