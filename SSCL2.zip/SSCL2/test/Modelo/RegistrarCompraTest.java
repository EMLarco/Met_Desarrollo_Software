
package Modelo;

import org.junit.Test;
import static org.junit.Assert.*;
import java.sql.*;
import java.util.Date;

public class RegistrarCompraTest {

    @Test
    public void testGuardarCompra() {
        RegistrarCompra registrarCompra = new RegistrarCompra();

        registrarCompra.txtNombreProducto.setText("Producto de prueba");
        registrarCompra.txtLote.setText("Lote123");
        registrarCompra.txtCantidadLote.setText("10");
        registrarCompra.txtCapacidad.setText("500");
        registrarCompra.dateChooserFechaIngreso.setDate(new Date());
        registrarCompra.dateChooserFechaCaducidad.setDate(new Date());
        registrarCompra.txtRazonCompra.setText("Compra de prueba");

        registrarCompra.guardarCompra();

        // Verificar si la compra se registró exitosamente en la base de datos
        try {
            String url = "jdbc:mysql://localhost/scl";
            String usuarioDB = "root";
            String contrasenaDB = "";

            Connection connection = DriverManager.getConnection(url, usuarioDB, contrasenaDB);
            Statement statement = connection.createStatement();

            ResultSet resultSet = statement.executeQuery("SELECT * FROM compras WHERE nombre_producto = 'Producto de prueba'");
            assertTrue(resultSet.next());

            // Limpiar la base de datos después de la prueba
            statement.executeUpdate("DELETE FROM compras WHERE nombre_producto = 'Producto de prueba'");

            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}