
package Modelo;

import org.junit.Test;
import static org.junit.Assert.*;



public class EditarPacienteFormTest {

    @Test
    public void testGuardarCambios() {
        // Se asume que existe un paciente con ID 1 en la base de datos para este test
        int idPaciente = 1;
        EditarPacienteForm editarPacienteForm = new EditarPacienteForm("Marcelo");

        // Modificar los datos del paciente en el formulario de edición
        editarPacienteForm.nombreField.setText("NuevoMarcelo");
        editarPacienteForm.apellidoField.setText("NuevoOso");

        // Probar guardar cambios
        boolean cambiosGuardados = editarPacienteForm.guardarCambios();

        // Verificar si los cambios se guardaron exitosamente
        assertTrue(cambiosGuardados);
    }
}
