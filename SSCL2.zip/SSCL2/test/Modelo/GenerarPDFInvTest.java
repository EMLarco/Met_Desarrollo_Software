package Modelo;

import org.junit.Test;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.io.File;

import static org.junit.Assert.assertTrue;

public class GenerarPDFInvTest {

    @Test
    public void testGenerarPDFInventario() {
        // Crear una tabla de ejemplo
        String[] columnNames = {"Producto", "Cantidad", "Precio"};
        Object[][] data = {
                {"Producto 1", 10, 50.0},
                {"Producto 2", 20, 30.0},
                {"Producto 3", 15, 40.0}
        };
        JTable table = new JTable(new DefaultTableModel(data, columnNames));

        // Generar el PDF de inventario
        GenerarPDFInv pdfGenerator = new GenerarPDFInv();
        pdfGenerator.generarPDFInventario(table);

        // Verificar si el archivo PDF se generó correctamente
        File pdfFile = new File("Inventario.pdf");
        assertTrue(pdfFile.exists());
    }
}
