package Modelo;

import static org.junit.Assert.*;
import org.junit.Test;
import java.util.ArrayList;

public class BuscarPacienteFormTest {

    @Test
    public void testBuscarPacientesPorNombre() {
        BuscarPacienteForm buscarPacienteForm = new BuscarPacienteForm();

        // Realizar una búsqueda de prueba
        ArrayList<String> resultados = buscarPacienteForm.buscarPacientesPorNombre("Juan");

        // Verificar si se encontraron resultados
        assertNotNull(resultados);
        assertFalse(resultados.isEmpty());

        // Verificar si al menos uno de los resultados comienza con "Juan"
        boolean encontrado = false;
        for (String resultado : resultados) {
            if (resultado.startsWith("Juan")) {
                encontrado = true;
                break;
            }
        }
        assertTrue(encontrado);
    }
}
