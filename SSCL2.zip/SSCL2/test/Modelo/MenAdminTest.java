package Modelo;

import org.junit.Test;
import static org.junit.Assert.*;

public class MenAdminTest {
    
    @Test
    public void testVerificarCredenciales_CorrectCredentials_ReturnsTrue() {
        // Se crea una instancia de la clase MenAdmin para realizar las pruebas.
        MenAdmin menAdmin = new MenAdmin();
        
        // Se llama al método verificarCredenciales con credenciales correctas y se guarda el resultado.
        boolean result = menAdmin.verificarCredenciales("JavierCevallos", "129062023");
        
        // Se verifica si el resultado es verdadero.
        assertTrue(result);
    }

    @Test
    public void testVerificarCredenciales_IncorrectCredentials_ReturnsFalse() {
        // Se crea una instancia de la clase MenAdmin para realizar las pruebas.
        MenAdmin menAdmin = new MenAdmin();
        
        // Se llama al método verificarCredenciales con credenciales incorrectas y se guarda el resultado.
        boolean result = menAdmin.verificarCredenciales("AldoSaula", "12345");
        
        // Se verifica si el resultado es falso.
        assertFalse(result);
    }
}
