package Modelo;

import org.junit.Test;

import static org.junit.Assert.*;

public class GenerarPDFCompraConHistorialTest {

    @Test
    public void testGenerarPDFCompraConHistorial() {
        GenerarPDFCompraConHistorial pdfGenerator = new GenerarPDFCompraConHistorial();
        pdfGenerator.generarPDFCompraConHistorial();

    }
}
