/*package Modelo;

import org.junit.Test;

import java.io.File;

import static org.junit.Assert.assertTrue;

public class GenerarPDFProveedorTest {

    @Test
    public void testGenerarPDF() {
        // Instanciar la clase GenerarPDFProveedor
        GenerarPDFProveedor pdfGenerator = new GenerarPDFProveedor();

        // Generar el PDF de proveedores
        byte[] pdfGenerado = pdfGenerator.generarPDFComoBytes();

        // Verificar si el PDF se generó correctamente
        assertTrue(pdfGenerado);

        // Verificar si el archivo PDF existe
        File pdfFile = new File("proveedores.pdf");
        assertTrue(pdfFile.exists());
    }
}*/
