
package Modelo;



import static org.junit.Assert.*;
import org.junit.Test;

public class EditarProveedorFormTest {

    @Test
    public void testGuardarCambios() {
        EditarProveedorForm editarProveedorForm = new EditarProveedorForm("Novavax"); // Suponiendo que el ID del proveedor a editar es 2
        
        // Modificar los campos de texto para simular cambios
        editarProveedorForm.nombreField.setText("Pfizer");
        editarProveedorForm.direccionField.setText("Nueva York, Nueva York, Estados Unidos");
        editarProveedorForm.telefonoField.setText("299999999"); // Cambiar este valor por un número válido
        
        // Guardar los cambios y verificar si se guardaron correctamente
        editarProveedorForm.guardarCambios();
        
        // Aquí puedes agregar alguna lógica adicional para verificar si los cambios se reflejaron correctamente en la base de datos
        // Por ejemplo, puedes volver a cargar los datos del proveedor y compararlos con los valores modificados.
        
        // Si no hay una forma directa de verificar si los cambios se guardaron correctamente, puedes simplemente verificar si no hubo errores durante la ejecución de guardarCambios()
        //assertTrue(true); // O simplemente afirmar que la ejecución llegó hasta aquí sin lanzar excepciones
    }
}
