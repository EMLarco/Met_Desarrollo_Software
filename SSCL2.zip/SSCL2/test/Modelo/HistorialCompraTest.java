package Modelo;

import org.junit.Test;

import javax.swing.*;
import java.awt.*;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class HistorialCompraTest {

    @Test
    public void testCargarDatosCompra() {
        // Instanciar la clase HistorialCompra
        HistorialCompra historialCompra = new HistorialCompra();

        // Obtener el panel de contenido de la ventana
        Container contentPane = historialCompra.getContentPane();

        // Obtener el componente JTable de la ventana
        JTable table = null;
        Component[] components = contentPane.getComponents();
        for (Component component : components) {
            if (component instanceof JScrollPane) {
                JScrollPane scrollPane = (JScrollPane) component;
                Component viewport = scrollPane.getViewport().getView();
                if (viewport instanceof JTable) {
                    table = (JTable) viewport;
                    break;
                }
            }
        }

        // Verificar si se pudo obtener la tabla
        assertNotNull(table);

        // Verificar si se cargaron datos en la tabla
        assertNotNull(table.getModel());
        assertTrue(table.getRowCount() > 0);
        assertTrue(table.getColumnCount() > 0);
    }
}
