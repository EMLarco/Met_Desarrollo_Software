-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 03-09-2023 a las 17:10:25
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `scl`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `compras`
--

CREATE TABLE `compras` (
  `com_codigo` int(11) NOT NULL,
  `nombre_producto` varchar(40) NOT NULL,
  `lote` varchar(40) NOT NULL,
  `cantidad_lote` int(11) NOT NULL,
  `capacidad` int(11) NOT NULL,
  `fecha_ingreso` date NOT NULL,
  `fecha_caducidad` date NOT NULL,
  `razon_compra` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `farmaceutica`
--

CREATE TABLE `farmaceutica` (
  `farm_code` int(11) NOT NULL,
  `fecha_uso` date NOT NULL,
  `medicamento` varchar(40) NOT NULL,
  `ml_usar` decimal(10,0) NOT NULL,
  `nombre_solicitante` varchar(40) NOT NULL,
  `paciente` varchar(40) NOT NULL,
  `zona_trabajada` varchar(40) NOT NULL,
  `razon_uso` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pacients`
--

CREATE TABLE `pacients` (
  `pac_code` int(11) NOT NULL,
  `pac_nombre` varchar(40) NOT NULL,
  `pac_apellido` varchar(40) NOT NULL,
  `pac_donombre` varchar(40) NOT NULL,
  `rep_nombre` varchar(40) NOT NULL,
  `rep_apellido` varchar(40) NOT NULL,
  `rep_parentezco` varchar(40) NOT NULL,
  `con_numcel` int(11) NOT NULL,
  `con_codearea` int(11) NOT NULL,
  `res_dire1` varchar(40) NOT NULL,
  `res_dire2` varchar(40) NOT NULL,
  `res_ciu` varchar(40) NOT NULL,
  `res_prov` varchar(40) NOT NULL,
  `res_pais` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedores`
--

CREATE TABLE `proveedores` (
  `pro_code` int(11) NOT NULL,
  `nombre` varchar(40) NOT NULL,
  `direccion` varchar(40) NOT NULL,
  `telefono` int(11) NOT NULL,
  `email` varchar(40) NOT NULL,
  `tipo_producto` varchar(40) NOT NULL,
  `sitio_web` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sscl`
--

CREATE TABLE `sscl` (
  `CC_code` int(11) NOT NULL,
  `CC_user` varchar(40) NOT NULL,
  `CC_pass` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `sscl`
--

INSERT INTO `sscl` (`CC_code`, `CC_user`, `CC_pass`) VALUES
(1, 'JavierCevallos', 129062023);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `compras`
--
ALTER TABLE `compras`
  ADD PRIMARY KEY (`com_codigo`);

--
-- Indices de la tabla `farmaceutica`
--
ALTER TABLE `farmaceutica`
  ADD PRIMARY KEY (`farm_code`);

--
-- Indices de la tabla `pacients`
--
ALTER TABLE `pacients`
  ADD PRIMARY KEY (`pac_code`);

--
-- Indices de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  ADD PRIMARY KEY (`pro_code`);

--
-- Indices de la tabla `sscl`
--
ALTER TABLE `sscl`
  ADD PRIMARY KEY (`CC_code`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `compras`
--
ALTER TABLE `compras`
  MODIFY `com_codigo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `farmaceutica`
--
ALTER TABLE `farmaceutica`
  MODIFY `farm_code` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `pacients`
--
ALTER TABLE `pacients`
  MODIFY `pac_code` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  MODIFY `pro_code` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `sscl`
--
ALTER TABLE `sscl`
  MODIFY `CC_code` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
