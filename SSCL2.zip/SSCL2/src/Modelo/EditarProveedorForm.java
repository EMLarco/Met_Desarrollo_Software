
package Modelo;

import Control.Conexion;
import com.mongodb.client.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import org.bson.Document;

public class EditarProveedorForm extends JFrame {
    JTextField nombreField;
    JTextField direccionField;
    JTextField telefonoField;
    private String nombre; // El ID del proveedor que se va a editar
    Conexion con = new Conexion();
    MongoClient mongo = con.obtenerConexion();
    MongoDatabase base = mongo.getDatabase("SSCL");
    Document antiguo = new Document();
    
    public EditarProveedorForm(String nombre) {
        this.nombre = nombre;

        setTitle("Editar Proveedor");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);        

        JPanel contentPane = new JPanel(new BorderLayout());
        contentPane.setBackground(Color.decode("#203B49"));

        nombreField = new JTextField(20);
        direccionField = new JTextField(20);
        telefonoField = new JTextField(20);

        JButton guardarButton = new JButton("Guardar");
        guardarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                guardarCambios();
            }
        });

        // Cargar datos del proveedor desde la base de datos
        cargarDatosProveedor();

        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(5, 5, 5, 5);

        formPanel.add(new JLabel("Nombre del Proveedor:"), gbc);
        gbc.gridy++;
        formPanel.add(nombreField, gbc);

        gbc.gridy++;
        formPanel.add(new JLabel("Dirección:"), gbc);
        gbc.gridy++;
        formPanel.add(direccionField, gbc);

        gbc.gridy++;
        formPanel.add(new JLabel("Teléfono:"), gbc);
        gbc.gridy++;
        formPanel.add(telefonoField, gbc);

        gbc.gridy++;
        formPanel.add(guardarButton, gbc);

        contentPane.add(formPanel, BorderLayout.CENTER);
        setContentPane(contentPane);
    }

    // Método para cargar datos del proveedor desde la base de datos
    private void cargarDatosProveedor() {
        MongoCollection coleccion = base.getCollection("Proveedores");
        MongoCursor<Document> cursor = coleccion.find(new Document("nombre",nombre)).cursor();
        try{
            Document dato = cursor.next();
            nombreField.setText(dato.getString("nombre"));
            direccionField.setText(dato.getString("direccion"));
            telefonoField.setText(dato.getString("telefono"));
            antiguo.clear();
            antiguo.append("nombre", dato.getString("nombre"))
                    .append("direccion", dato.getString("direccion"))
                    .append("telefono", dato.getString("telefono"));
        }catch(Exception e){
            JOptionPane.showMessageDialog(this, "Proveedor no encontrado.", "Error", JOptionPane.ERROR_MESSAGE);
            dispose();
        }
    }

    // Método para guardar cambios en la base de datos
    void guardarCambios() {
        MongoCollection coleccion = base.getCollection("Proveedores");
        Document nuevo = new Document();

        String nuevoNombre = nombreField.getText();
        String nuevaDireccion = direccionField.getText();
        String nuevoTelefono = telefonoField.getText();
        
        nuevo.append("nombre", nuevoNombre).append("direccion", nuevaDireccion).append("telefono", nuevoTelefono);
        Document update = new Document("$set",nuevo);
        coleccion.updateOne(antiguo, update);
        JOptionPane.showMessageDialog(this, "Proveedor actualizado con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        dispose(); // Cierra la ventana después de guardar
    }


}
