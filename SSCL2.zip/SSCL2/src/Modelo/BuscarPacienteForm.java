package Modelo;

import Control.Conexion;
import com.mongodb.client.*;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.event.*;
import java.awt.*;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.DefaultListModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import org.bson.Document;

public class BuscarPacienteForm extends JFrame {
    private JTextField nombreField;
    private JList<String> resultadosList;
    
    Conexion con = new Conexion();
    MongoClient mongo = con.obtenerConexion();
    MongoDatabase base = mongo.getDatabase("SSCL");
    
    public BuscarPacienteForm() {
        setTitle("Búsqueda de Paciente");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Establece el color de fondo en #203B49
        getContentPane().setBackground(Color.decode("#203B49"));

        JPanel contentPane = new JPanel(new BorderLayout());
        contentPane.setBackground(Color.decode("#203B49"));

        JPanel busquedaPanel = new JPanel(new BorderLayout());
        busquedaPanel.setBackground(Color.decode("#203B49"));
        contentPane.add(busquedaPanel, BorderLayout.NORTH);

        JLabel lblNombre = new JLabel("Nombre del Paciente:");
        lblNombre.setForeground(Color.WHITE);

        nombreField = new JTextField();
        nombreField.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                actualizarResultados();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                actualizarResultados();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                // No relevante para campos de texto
            }
        });

        resultadosList = new JList();
        resultadosList.setForeground(Color.decode("#000")); // Texto en negro
        JScrollPane resultadosScrollPane = new JScrollPane(resultadosList);

        busquedaPanel.add(lblNombre, BorderLayout.NORTH);
        busquedaPanel.add(nombreField, BorderLayout.CENTER);
        contentPane.add(resultadosScrollPane, BorderLayout.CENTER);

        // Configura los colores de fondo de los componentes
        nombreField.setBackground(Color.decode("#E0E0E0")); // Fondo gris claro
        resultadosScrollPane.getViewport().setBackground(Color.decode("#FFF")); // Fondo blanco

        setContentPane(contentPane);

        // Agregar un ListSelectionListener a la lista de resultados
        resultadosList.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    // Obtener el paciente seleccionado
                    String pacienteSeleccionado = resultadosList.getSelectedValue();

                    if (pacienteSeleccionado != null) {
                        // Mostrar la ventana de detalles del paciente
                        mostrarDetallesPaciente(pacienteSeleccionado);
                    }
                }
            }
        });
    }

    // Método para actualizar los resultados de búsqueda
    private void actualizarResultados() {
        String nombre = nombreField.getText().trim();

        // Realizar la búsqueda en la base de datos y obtener los resultados
        ArrayList<String> resultados = buscarPacientesPorNombre(nombre);

        // Actualizar la lista de resultados en la interfaz gráfica
        DefaultListModel listModel = new DefaultListModel();
        for (String resultado : resultados) {
            listModel.addElement(resultado);
        }
        resultadosList.setModel(listModel);
    }

    // Método para buscar pacientes por nombre en la base de datos
   public ArrayList<String> buscarPacientesPorNombre(String nombre) {
        ArrayList<String> resultados = new ArrayList<>();
        
        MongoCollection coleccion = base.getCollection("Pacients");
        Document regex = new Document("pac_nombre",new Document("$regex",nombre));
        try{
            MongoCursor<Document> cursor = coleccion.find(regex).iterator();
            while(cursor.hasNext()){
                Document dato = cursor.next();
                String nombrePaciente = dato.getString("pac_nombre");
                resultados.add(nombrePaciente);
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(this, "Error al buscar pacientes: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        return resultados;
    }

    // Método para mostrar los detalles de un paciente
    private void mostrarDetallesPaciente(String nombrePaciente) {
        // Crear una nueva ventana o diálogo para mostrar los detalles del paciente
        JFrame detallesFrame = new JFrame("Detalles del Paciente");
        detallesFrame.setSize(400, 300);

        // Establecer el color de fondo en #203B49
        detallesFrame.getContentPane().setBackground(Color.decode("#203B49"));

        JPanel detallesPanel = new JPanel(new BorderLayout());
        detallesPanel.setBackground(Color.decode("#203B49"));

        // Obtener y mostrar los detalles del paciente desde la base de datos
        JTextArea detallesTextArea = new JTextArea();
        detallesTextArea.setBackground(Color.decode("#203B49")); // Fondo gris claro
        detallesTextArea.setForeground(Color.WHITE); // Color de letra blanco

        // Realizar la consulta para obtener los detalles del paciente por nombre
        String detalles = obtenerDetallesPaciente(nombrePaciente);

        // Establecer los detalles en el área de texto
        detallesTextArea.setText(detalles);

        detallesPanel.add(new JScrollPane(detallesTextArea), BorderLayout.CENTER);
        detallesFrame.setContentPane(detallesPanel);
        detallesFrame.setVisible(true);
    }

    // Método para obtener los detalles del paciente desde la base de datos
    private String obtenerDetallesPaciente(String nombrePaciente) {
        String detalles = "";
        MongoCollection coleccion = base.getCollection("Pacients");
        MongoCursor<Document> cursor = coleccion.find(new Document("pac_nombre",nombrePaciente)).cursor();
        try{
            Document dato = cursor.next();
            detalles += "Nombre: " + dato.getString("pac_nombre") + "\n";
            detalles += "Segundo Nombre: " + dato.getString("pac_donombre") + "\n";
            detalles += "Apellido: " + dato.getString("pac_apellido") + "\n";
            detalles += "Nombre del Representante: " + dato.getString("rep_nombre") + "\n";
            detalles += "Apellido del Representante: " + dato.getString("rep_apellido") + "\n";
            detalles += "Parentezco: " + dato.getString("rep_parentezco") + "\n";
            detalles += "Numero Telefonico: " + dato.getString("con_numcel") + "\n";
            detalles += "Codigo de Area: " + dato.getString("con_codearea") + "\n";
            detalles += "Dirección de la calle: " + dato.getString("res_dire1") + "\n";
            detalles += "Dirección de la calla 2: " + dato.getString("res_dire2") + "\n";
            detalles += "Ciudad: " + dato.getString("res_ciu") + "\n";
            detalles += "Provincia: " + dato.getString("res_prov") + "\n";
            detalles += "Pais: " + dato.getString("res_pais") + "\n";
        }catch(Exception e){
        }
        return detalles;
    }


}
