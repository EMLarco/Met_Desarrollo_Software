
package Modelo;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import javax.swing.JTable;
import java.io.FileOutputStream;
import javax.swing.JOptionPane;

public class GenerarPDFInv {

    public void generarPDFInventario(JTable table) {
        Document document = new Document();
        
        // Color de fondo personalizado
        BaseColor backgroundColor = new BaseColor(32, 59, 73); // Por ejemplo, un color azul oscuro

        try {
            // Especifica la ubicación y el nombre del archivo PDF a generar
            PdfWriter.getInstance(document, new FileOutputStream("Inventario.pdf"));
            document.open();

            // Agrega un título al documento
            Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18);
            titleFont.setColor(BaseColor.BLACK); // Color de texto
            Paragraph title = new Paragraph("Inventario", titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            
            // Fondo de título personalizado
            title.setSpacingAfter(20); // Espacio después del título
            
            document.add(title);

            // Crea una tabla para los datos del inventario
            PdfPTable pdfTable = new PdfPTable(table.getColumnCount());
            
            // Configura el color de fondo de la tabla
            pdfTable.getDefaultCell().setBackgroundColor(backgroundColor);
            
            // Agrega las columnas de la tabla
            for (int i = 0; i < table.getColumnCount(); i++) {
                PdfPCell cell = new PdfPCell(new Phrase(table.getColumnName(i)));
                cell.setBackgroundColor(backgroundColor); // Color de fondo de las celdas de encabezado
                cell.setHorizontalAlignment(Element.ALIGN_CENTER); // Alineación de texto
                pdfTable.addCell(cell);
            }
            
            // Agrega filas y celdas a la tabla
            for (int row = 0; row < table.getRowCount(); row++) {
                for (int column = 0; column < table.getColumnCount(); column++) {
                    pdfTable.addCell(new Phrase(table.getValueAt(row, column).toString()));
                }
            }
            
            // Agrega la tabla al documento
            document.add(pdfTable);

            // Cierra el documento
            document.close();

            // Muestra un mensaje de éxito
            JOptionPane.showMessageDialog(null, "PDF de inventario generado con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error al generar el PDF de inventario.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
