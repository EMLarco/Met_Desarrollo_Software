package Modelo;

import Control.Conexion;
import com.mongodb.client.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import org.bson.Document;

public class HistorialUsosFarm extends JFrame {
    private JTable table;
    
    Conexion con = new Conexion();
    MongoClient mongo = con.obtenerConexion();
    MongoDatabase base = mongo.getDatabase("SSCL");
    
    public HistorialUsosFarm() {
        setTitle("Historial de Usos");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        DefaultTableModel tableModel = new DefaultTableModel();
        tableModel.addColumn("Nombre del Solicitante");
        tableModel.addColumn("Paciente");
        tableModel.addColumn("Medicamento");
        tableModel.addColumn("Cantidad de Uso");
        tableModel.addColumn("Razón");

        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        // Llena la tabla desde la base de datos farmacéutica
        llenarTablaDesdeBDFarmaceutica(tableModel);

        getContentPane().add(scrollPane, BorderLayout.CENTER);  
    }
    
    

private void llenarTablaDesdeBDFarmaceutica(DefaultTableModel tableModel) {
    MongoCollection coleccion = base.getCollection("Farmaceutica");
    MongoCursor<Document> cursor = coleccion.find().cursor();
    // Limpia la tabla antes de agregar nuevos datos
    tableModel.setRowCount(0);
    while(cursor.hasNext()){
        Document dato = cursor.next();
        String nombreSolicitante = dato.getString("nombre_solicitante");
        String paciente = dato.getString("paciente");
        String medicamento = dato.getString("medicamento");
        int mlUsar = dato.getInteger("ml_usar");
        String razonUso = dato.getString("razon_uso");
        tableModel.addRow(new Object[]{nombreSolicitante, paciente, medicamento, mlUsar, razonUso});
    }
}

 
    


}
