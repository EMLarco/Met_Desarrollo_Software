package Modelo;

import Control.Conexion;
import com.mongodb.client.*;
import Modelo.EnvioCorreo;
import com.mongodb.Function;
import org.bson.Document;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.mail.MessagingException;

public class RegistroProveedorForm extends JFrame {
    private JTextField nombreProveedorField;
    private JTextField direccionField;
    private JTextField telefonoField;
    private JTextField emailField;
    private JTextField tipoProductoField;
    private JTextField sitioWebField;
    private JTextField nombreProductoField;
    private JTextField loteField;
    private JTextField usosDisponiblesField;
    private JTextField estadoField;
    private JTextField emailProveedorField; // Nuevo campo para el correo del proveedor

    Conexion con = new Conexion();
    MongoClient mongo = con.obtenerConexion();
    MongoDatabase base = mongo.getDatabase("SSCL");

    public RegistroProveedorForm(SSCLmenu parentFrame) {
        setTitle("Registro de Proveedor y Producto");
        setSize(700, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel contentPane = new JPanel(new BorderLayout());
        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        formPanel.setBackground(Color.decode("#203B49"));

        // Función para crear un JPanel que contenga un JLabel y un JTextField con ancho y largo fijos
        Function<String, JPanel> createLabeledTextField = labelText -> {
            JPanel panel = new JPanel(new BorderLayout());
            JLabel label = new JLabel(labelText);
            label.setForeground(Color.BLACK); // Letras negras
            label.setPreferredSize(new Dimension(150, 30)); // Ancho y largo fijos
            panel.add(label, BorderLayout.WEST);

            JTextField textField = new JTextField(20);
            textField.setPreferredSize(new Dimension(200, 30)); // Ancho y largo fijos
            panel.add(textField, BorderLayout.CENTER);
            return panel;
        };

        nombreProveedorField = ((JTextField) createLabeledTextField.apply("Nombre del Proveedor").getComponent(1));
        direccionField = ((JTextField) createLabeledTextField.apply("Dirección").getComponent(1));
        telefonoField = ((JTextField) createLabeledTextField.apply("Teléfono").getComponent(1));
        emailProveedorField = ((JTextField) createLabeledTextField.apply("Correo del Proveedor").getComponent(1));
        tipoProductoField = ((JTextField) createLabeledTextField.apply("Tipo de Producto").getComponent(1));
        sitioWebField = ((JTextField) createLabeledTextField.apply("Sitio Web").getComponent(1));

        JLabel lblFecha = new JLabel("Fecha:  ");
        lblFecha.setForeground(Color.WHITE); // Letras negras
        gbc.gridx = 0;
        gbc.gridy = 7;
        formPanel.add(lblFecha, gbc);

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(10, 10, 10, 10);

        gbc.gridy++;
        formPanel.add(nombreProveedorField.getParent(), gbc);

        gbc.gridy++;
        formPanel.add(direccionField.getParent(), gbc);

        gbc.gridy++;
        formPanel.add(telefonoField.getParent(), gbc);

        gbc.gridy++;
        formPanel.add(emailProveedorField.getParent(), gbc);

        gbc.gridy++;
        formPanel.add(tipoProductoField.getParent(), gbc);

        gbc.gridy++;
        formPanel.add(sitioWebField.getParent(), gbc);

        gbc.gridy++;

        JButton guardarButton = new JButton("Guardar");
        guardarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                guardarProveedorYProducto();
            }
        });

        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        formPanel.add(guardarButton, gbc);

        contentPane.add(formPanel, BorderLayout.CENTER);

        setContentPane(contentPane);
    }

    private void guardarProveedorYProducto() {
        String nombreProveedor = nombreProveedorField.getText();
        String direccion = direccionField.getText();
        String telefono = telefonoField.getText();
        String emailP = emailProveedorField.getText();
        String tipoProducto = tipoProductoField.getText();
        String sitioWeb = sitioWebField.getText();

        if (nombreProveedor.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos obligatorios.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        MongoCollection coleccion = base.getCollection("Proveedores");
        Document dato = new Document();
        dato.append("nombre", nombreProveedor)
            .append("direccion", direccion)
            .append("telefono", telefono)
            .append("email", emailP) // Corrección: el campo se llama "email", no "Correo del Proveedor"
            .append("tipo_producto", tipoProducto)
            .append("sitio_web", sitioWeb);

        coleccion.insertOne(dato);

        // Generar PDF
        GenerarPDFProveedor generadorPDF = new GenerarPDFProveedor();
        byte[] pdfBytes = generadorPDF.generarPDFComoBytes();

        if (pdfBytes != null) {
            try {
                // Enviar el correo con el PDF adjunto
                EnvioCorreo.enviarCorreoConAdjunto(emailP, "Asunto del Correo", "PDF PROVEDOR", pdfBytes);
                JOptionPane.showMessageDialog(this, "Proveedor registrado con éxito. Correo enviado correctamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } catch (MessagingException ex) {
                JOptionPane.showMessageDialog(this, "Proveedor registrado con éxito, pero ocurrió un error al enviar el correo.", "Error", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Proveedor registrado con éxito, pero ocurrió un error al generar el PDF.", "Error", JOptionPane.ERROR_MESSAGE);
        }

        dispose();
    }
}
