package Modelo;

import Control.Conexion;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.mongodb.client.*;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class GenerarPDFProveedor {

    Conexion con = new Conexion();
    MongoClient mongo = con.obtenerConexion();
    MongoDatabase base = mongo.getDatabase("SSCL");

    public byte[] generarPDFComoBytes() {
    try {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        Document document = new Document();
        PdfWriter.getInstance(document, baos);
        document.open();

        // Agregar la imagen en la esquina superior derecha
        Image imagen = Image.getInstance("src\\imagen\\lofo.png");
        imagen.scaleToFit(100, 100);
        imagen.setAlignment(Element.ALIGN_RIGHT);
        document.add(imagen);

        // Título
        Font fontTitulo = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 20, BaseColor.BLACK);
        Paragraph titulo = new Paragraph("Lista de Proveedores", fontTitulo);
        titulo.setAlignment(Element.ALIGN_CENTER);
        document.add(titulo);

        // Espacio
        document.add(new Paragraph("\n"));

        // Crear tabla para mostrar los datos de los proveedores
        PdfPTable tabla = new PdfPTable(1);
        tabla.setWidthPercentage(100);

        // Estilo para el contenido de la tabla
        Font fontContenido = FontFactory.getFont(FontFactory.HELVETICA, 12, BaseColor.BLACK);

        MongoCollection coleccion = base.getCollection("Proveedores");
        MongoCursor<org.bson.Document> cursor = coleccion.find().cursor();
        while (cursor.hasNext()) {
            org.bson.Document dato = cursor.next();

            // Datos del proveedor
            StringBuilder proveedorData = new StringBuilder();
            proveedorData.append("Nombre: ").append(dato.getString("nombre")).append("\n");
            proveedorData.append("Dirección: ").append(dato.getString("direccion")).append("\n");
            proveedorData.append("Teléfono: ").append(dato.getString("telefono")).append("\n");
            proveedorData.append("Email: ").append(dato.getString("email")).append("\n");
            proveedorData.append("Tipo de Producto: ").append(dato.getString("tipo_producto")).append("\n");
            proveedorData.append("Sitio Web: ").append(dato.getString("sitio_web")).append("\n");

            PdfPCell cell = new PdfPCell(new Phrase(proveedorData.toString(), fontContenido));
            cell.setBorder(Rectangle.NO_BORDER);
            tabla.addCell(cell);
        }

        document.add(tabla);
        document.close();
        return baos.toByteArray();
    } catch (Exception e) {
        e.printStackTrace();
        return null;
    }
}
}


