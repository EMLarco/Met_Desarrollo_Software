package Modelo;


import Control.Conexion;
import com.mongodb.client.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import org.bson.Document;

public class HistorialCompra extends JFrame {
    private JTable table;
    
    Conexion con = new Conexion();
    MongoClient mongo = con.obtenerConexion();
    MongoDatabase base = mongo.getDatabase("SSCL");
    
    public HistorialCompra() {
        setTitle("Historial de Compra");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel contentPane = new JPanel(new BorderLayout());

        // Crear una tabla para mostrar los datos de compra
        table = new JTable();
        JScrollPane scrollPane = new JScrollPane(table);
        contentPane.add(scrollPane, BorderLayout.CENTER);

        setContentPane(contentPane);

        // Cargar y mostrar los datos de compra en la tabla
        cargarDatosCompra();
    }

    private void cargarDatosCompra() {
        MongoCollection coleccion = base.getCollection("Compras");
        MongoCursor<Document> cursor = coleccion.find().cursor();
        // Crea el modelo de tabla para almacenar los datos
        DefaultTableModel modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("Nombre del Producto");
        modeloTabla.addColumn("Fecha de Ingreso");
        modeloTabla.addColumn("Lote");
        modeloTabla.addColumn("Razón");
        modeloTabla.addColumn("Cantidad");

        // Agrega las filas de datos a la tabla
        while (cursor.hasNext()) {
            Document datos = cursor.next();        
            String nombreProducto = datos.getString("nombre_producto");
            String fechaIngreso = datos.getDate("fecha_ingreso").toString();
            String lote = datos.getString("lote");
            String razon = datos.getString("razon_compra");
            int cantidad = datos.getInteger("cantidad_lote");

            modeloTabla.addRow(new Object[]{nombreProducto, fechaIngreso, lote, razon, cantidad});
        }

        // Asigna el modelo de tabla a la JTable
        table.setModel(modeloTabla);
        
        // Configura la conexión a la base de datos (debes ajustar la URL, usuario y contraseña)
        String url = "jdbc:mysql://localhost/scl";
        String usuario = "root";
        String contraseña = "";
    }

}
