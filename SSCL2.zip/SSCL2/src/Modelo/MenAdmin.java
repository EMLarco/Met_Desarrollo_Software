package Modelo;

import Control.Conexion;
import com.mongodb.client.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.geom.RoundRectangle2D;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import javax.swing.JOptionPane;
import org.bson.Document;


public class MenAdmin extends JFrame {
    
    Conexion con = new Conexion();
    MongoClient mongo = con.obtenerConexion();
    
    public MenAdmin() {
        setTitle("Inicio de Sesión");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Color backgroundColor = Color.decode("#112E51");
        Color backgroundColor1 = Color.decode("#316D94");
        Color backgroundColor2 = Color.decode("#FFFFFF");

        JPanel fondoPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Cargar la imagen de fondo
                ImageIcon imageIcon = new ImageIcon(getClass().getResource("/imagen/MenAdmin.png")); // Asegúrate de que la imagen esté en el mismo directorio que tu clase
                Image image = imageIcon.getImage();
                // Dibujar la imagen de fondo
                g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
            }
        };
        fondoPanel.setLayout(null);
        
                        // Función para crear un borde redondeado
        Border bordeRedondeado = new Border() {
            int radio = 15; // Ajusta el radio según tu preferencia

            @Override
            public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
                g.setColor(Color.decode("#829DAE")); // Color del borde
                ((Graphics2D) g).draw(new RoundRectangle2D.Double(x, y, width - 1, height - 1, radio, radio));
            }

            @Override
            public Insets getBorderInsets(Component c) {
                return new Insets(radio, radio, radio, radio);
            }

            @Override
            public boolean isBorderOpaque() {
                return false;
            }
        };
        

        Font timesNewRomanBold = new Font("Times New Roman", Font.BOLD, 18);
        Font timesNewRomanBold1 = new Font("Times New Roman", Font.BOLD, 18);

        // Campo de texto para el nombre de usuario
        JTextField txtUsuario = new JTextField();
        txtUsuario.setBounds(155, 214, 170, 32);
        txtUsuario.setBackground(Color.decode("#112E51"));
        txtUsuario.setForeground(Color.WHITE);
        txtUsuario.setFont(timesNewRomanBold1);
        txtUsuario.setBorder(new LineBorder(backgroundColor, 2));
         // Agregar un FocusListener para manejar el texto de pista
        txtUsuario.addFocusListener(new FocusListener() {
            @Override
            public void focusGained(FocusEvent e) {
                if (txtUsuario.getText().equals("Ingresar usuario")) {
                    txtUsuario.setText("");
                    txtUsuario.setForeground(Color.WHITE); // Cambiar el color del texto al escribir
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (txtUsuario.getText().isEmpty()) {
                    txtUsuario.setText("Ingresar usuario");
                    txtUsuario.setForeground(Color.GRAY); // Restaurar el color del texto de pista
                }
            }
        });
        fondoPanel.add(txtUsuario);


        // Campo de contraseña
        JPasswordField txtContraseña = new JPasswordField();
        txtContraseña.setBounds(155, 258, 170, 32);
        txtContraseña.setBackground(Color.decode("#316D94"));
        txtContraseña.setForeground(Color.WHITE);
        txtContraseña.setFont(timesNewRomanBold1);
        txtContraseña.setBorder(new LineBorder(backgroundColor1, 2));
        //Agregar un FocusListener para manejar el texto de pista
        txtContraseña.addFocusListener(new FocusListener(){
        @Override
        public void focusGained(FocusEvent e){
            String contraseñaPista = "Ingresar contraseña";
            if(new String(txtContraseña.getPassword()).equals(contraseñaPista)){
                txtContraseña.setText("");
                txtContraseña.setForeground(Color.WHITE);
                txtContraseña.setEchoChar('*');
            
            }
        }
        
        @Override
        public void focusLost(FocusEvent e){
            String contraseña = new String(txtContraseña.getPassword());
            if(contraseña.isEmpty()){
                txtContraseña.setText("Ingresar contraseña");
                txtContraseña.setForeground(Color.GRAY);
                txtContraseña.setEchoChar((char)0);
            }
        }
    });
        fondoPanel.add(txtContraseña);

        // Botón de inicio de sesión
        JButton btnIniciarSesion = new JButton("Iniciar Sesión");
        btnIniciarSesion.setBounds(160, 347, 160, 20);
        btnIniciarSesion.setBackground(Color.decode("#FFFFFF"));
        btnIniciarSesion.setFont(timesNewRomanBold1);
        btnIniciarSesion.setBorder(bordeRedondeado);
        btnIniciarSesion.setBorder(new LineBorder(backgroundColor2, 2));
        fondoPanel.add(btnIniciarSesion);
        

        // Agregar un ActionListener al botón de inicio de sesión
        btnIniciarSesion.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Obtener el usuario y la contraseña ingresados
                String usuario = txtUsuario.getText();
                String contraseña = new String(txtContraseña.getPassword());

                // Realizar la verificación en la base de datos
                if (verificarCredenciales(usuario, contraseña)) {
                    JOptionPane.showMessageDialog(null, "Inicio de sesión exitoso");

                    // Abre la ventana SSCLmenu
                    SwingUtilities.invokeLater(new Runnable() {
                        @Override
                        public void run() {
                            SSCLmenu menu=new SSCLmenu();
                            menu.setVisible(true);
                        }
                    });

                    // Cierra la ventana de inicio de sesión
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "Nombre de usuario o contraseña incorrectos");
                }
            }
        });
    


        // Centrar el panel en la ventana
        fondoPanel.setBounds(0, 0, 500, 500);
        getContentPane().add(fondoPanel);

        // Centrar la ventana en la pantalla
        setLocationRelativeTo(null);
        
        // Agregar los botones al panel de fondo
        fondoPanel.add(txtUsuario);
        fondoPanel.add(txtContraseña);
    }
    
    // Función para verificar las credenciales en la base de datos
    public boolean verificarCredenciales(String usuario, String contraseña) {
        
    MongoDatabase base = mongo.getDatabase("SSCL");
    MongoCollection coleccion = base.getCollection("Credencial");
    Document credenciales = new Document();
    credenciales.append("CC_user", usuario).append("CC_pass", contraseña); 
    
    try{
        MongoCursor<Document> cursor = coleccion.find(credenciales).cursor();
         cursor.next();
         return true;
    }catch(Exception e){
        return false;
    }
    
}
}
