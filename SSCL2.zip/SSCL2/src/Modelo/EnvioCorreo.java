package Modelo;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;

public class EnvioCorreo {

    public static void enviarCorreoConAdjunto(String correoDestinatario, String asunto, String cuerpo, byte[] rutaArchivoAdjunto) throws MessagingException {
        // Configurar las propiedades para la conexión SMTP
        Properties propiedades = new Properties();
        propiedades.put("mail.smtp.host", "smtp.gmail.com"); // Cambia esto por tu servidor SMTP
        propiedades.put("mail.smtp.port", "587"); // Puerto SMTP
        propiedades.put("mail.smtp.auth", "true"); // Autenticación requerida
        propiedades.put("mail.smtp.starttls.enable", "true"); // Habilitar TLS

        // Autenticación del remitente
        Authenticator autenticador = new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication("aldodszpoo@gmail.com", "rxfa rxlq stqk uaan"); // Cambia esto por tu correo y contraseña
            }
        };

        // Crear una sesión de correo
        Session sesion = Session.getInstance(propiedades, autenticador);

        try {
            // Crear un mensaje de correo electrónico
            Message mensaje = new MimeMessage(sesion);
            mensaje.setFrom(new InternetAddress("aldodszpoo@gmail.com")); // Dirección de correo del remitente
            mensaje.setRecipient(Message.RecipientType.TO, new InternetAddress(correoDestinatario)); // Dirección de correo del destinatario
            mensaje.setSubject(asunto); // Asunto del correo

            // Crear el cuerpo del correo
            MimeBodyPart parteCuerpoMensaje = new MimeBodyPart();
            parteCuerpoMensaje.setText(cuerpo); // Cuerpo del correo

            // Crear el archivo adjunto (el PDF)
            MimeBodyPart parteArchivoAdjunto = new MimeBodyPart();
            // Convertir el array de bytes a un archivo temporal
            File archivoAdjunto = File.createTempFile("adjunto", ".pdf");
            FileOutputStream fos = new FileOutputStream(archivoAdjunto);
            fos.write(rutaArchivoAdjunto);
            fos.close();
            parteArchivoAdjunto.attachFile(archivoAdjunto); // Adjuntar el archivo temporal

            // Combinar el cuerpo del correo y el archivo adjunto
            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(parteCuerpoMensaje);
            multipart.addBodyPart(parteArchivoAdjunto);

            // Establecer el contenido del mensaje
            mensaje.setContent(multipart);

            // Enviar el correo electrónico
            Transport.send(mensaje);
            System.out.println("Correo enviado correctamente!");

            // Eliminar el archivo temporal después de enviar el correo
            archivoAdjunto.delete();
        } catch (Exception e) {
            e.printStackTrace();
            throw new MessagingException("Error al enviar el correo electrónico: " + e.getMessage());
        }
    }
}
