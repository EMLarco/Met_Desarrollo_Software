
package Modelo;

import Control.Conexion;
import com.mongodb.client.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import org.bson.Document;

public class EditarPacienteForm extends JFrame {
    JTextField nombreField;
    JTextField apellidoField;
    private JButton guardarButton;
    private String nombre; // ID del paciente que se está editando
    
    Document antiguo = new Document();
    Conexion con = new Conexion();
    MongoClient mongo = con.obtenerConexion();
    MongoDatabase base = mongo.getDatabase("SSCL");

    public EditarPacienteForm(String nombre) {
        this.nombre = nombre; // Almacena el ID del paciente a editar

        setTitle("Editar Paciente");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel contentPane = new JPanel(new BorderLayout());

        JPanel datosPanel = new JPanel(new GridLayout(2, 2));
        nombreField = new JTextField();
        apellidoField = new JTextField();

        // Agregar componentes para editar los datos del paciente
        datosPanel.add(new JLabel("Nombre:"));
        datosPanel.add(nombreField);
        datosPanel.add(new JLabel("Apellido:"));
        datosPanel.add(apellidoField);

        guardarButton = new JButton("Guardar");
        guardarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Lógica para guardar los cambios en el paciente
                if (guardarCambios()) {
                    // Cierra la ventana de edición si se guardaron los cambios exitosamente
                    dispose();
                }
            }
        });

        contentPane.add(datosPanel, BorderLayout.CENTER);
        contentPane.add(guardarButton, BorderLayout.SOUTH);

        setContentPane(contentPane);

        // Cargar los datos del paciente para editar
        cargarDatosPaciente();
    }

    // Método para cargar los datos del paciente para editar
    private void cargarDatosPaciente() {
        MongoCollection coleccion = base.getCollection("Pacients");
        MongoCursor<Document> cursor = coleccion.find(new Document("pac_nombre",nombre)).cursor();
        try{
            Document datos = cursor.next();
            nombreField.setText(datos.getString("pac_nombre"));
            apellidoField.setText(datos.getString("pac_apellido"));
            antiguo.clear();
            antiguo.append("pac_nombre", datos.getString("pac_nombre"))
                    .append("pac_apellido", datos.getString("pac_apellido"));
        }catch(Exception e){
        }
    }

    // Método para guardar los cambios en el paciente
    boolean guardarCambios() {
        try{
            MongoCollection coleccion = base.getCollection("Pacients");
            Document nuevo = new Document();
            nuevo.append("pac_nombre", nombreField.getText())
                 .append("pac_apellido", apellidoField.getText());
            Document update = new Document("$set",nuevo);
            coleccion.updateOne(antiguo, update);
            JOptionPane.showMessageDialog(this, "Cambios guardados exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            return true;
        }catch(Exception e){
            JOptionPane.showMessageDialog(this, "Error","Error",JOptionPane.ERROR_MESSAGE);
        }
        return false; // Error al guardar los cambios
    }
}
