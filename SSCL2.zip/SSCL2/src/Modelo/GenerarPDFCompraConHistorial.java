package Modelo;

import Control.Conexion;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.mongodb.client.*;

import java.io.FileOutputStream;

    public class GenerarPDFCompraConHistorial {
        
        Conexion con = new Conexion();
        MongoClient mongo = con.obtenerConexion();
        MongoDatabase base = mongo.getDatabase("SSCL");
        
         private static BaseColor colorFondoCelda = new BaseColor(224, 224, 224);
        public void generarPDFCompraConHistorial() {
            String pdfFilePath = "Lista_compras.pdf";
            
            Document document = new Document();
            
            
            // Define colores personalizados
            BaseColor colorFondoEncabezado = new BaseColor(32, 59, 73);
            BaseColor colorFondoCelda = new BaseColor(224, 224, 224);

            try {
                PdfWriter.getInstance(document, new FileOutputStream(pdfFilePath));
                document.open();

                // Tabla de datos de compra
                PdfPTable tablaCompra = new PdfPTable(4);
                tablaCompra.setWidthPercentage(100);
                tablaCompra.setSpacingBefore(10f);
                tablaCompra.setSpacingAfter(10f);

                // Estilo para el encabezado de columna
                PdfPCell encabezadoCell = new PdfPCell();
                encabezadoCell.setBackgroundColor(colorFondoEncabezado);
                encabezadoCell.setHorizontalAlignment(Element.ALIGN_CENTER);
                encabezadoCell.setVerticalAlignment(Element.ALIGN_MIDDLE);
                encabezadoCell.setBorderColor(BaseColor.WHITE);
                encabezadoCell.setPhrase(new Phrase("Nombre del Producto", FontFactory.getFont(FontFactory.HELVETICA_BOLD)));
                tablaCompra.addCell(encabezadoCell);

                encabezadoCell.setPhrase(new Phrase("Lote", FontFactory.getFont(FontFactory.HELVETICA_BOLD)));
                tablaCompra.addCell(encabezadoCell);

                encabezadoCell.setPhrase(new Phrase("Fecha de Ingreso", FontFactory.getFont(FontFactory.HELVETICA_BOLD)));
                tablaCompra.addCell(encabezadoCell);

                encabezadoCell.setPhrase(new Phrase("Cantidad", FontFactory.getFont(FontFactory.HELVETICA_BOLD)));
                tablaCompra.addCell(encabezadoCell);

                // Agregar datos de compra desde la base de datos
                obtenerDatosCompraDesdeBD(tablaCompra);

                document.add(tablaCompra);

                // Agregar una nueva página para el historial de compras
                document.newPage();

                // Tabla de historial de compras
                PdfPTable tablaHistorial = new PdfPTable(5);
                tablaHistorial.setWidthPercentage(100);
                tablaHistorial.setSpacingBefore(10f);
                tablaHistorial.setSpacingAfter(10f);

                // Estilo para el encabezado de columna
                encabezadoCell.setPhrase(new Phrase("Nombre del Producto", FontFactory.getFont(FontFactory.HELVETICA_BOLD)));
                tablaHistorial.addCell(encabezadoCell);

                encabezadoCell.setPhrase(new Phrase("Fecha", FontFactory.getFont(FontFactory.HELVETICA_BOLD)));
                tablaHistorial.addCell(encabezadoCell);

                encabezadoCell.setPhrase(new Phrase("Lote", FontFactory.getFont(FontFactory.HELVETICA_BOLD)));
                tablaHistorial.addCell(encabezadoCell);

                encabezadoCell.setPhrase(new Phrase("Razón", FontFactory.getFont(FontFactory.HELVETICA_BOLD)));
                tablaHistorial.addCell(encabezadoCell);

                encabezadoCell.setPhrase(new Phrase("Cantidad", FontFactory.getFont(FontFactory.HELVETICA_BOLD)));
                tablaHistorial.addCell(encabezadoCell);

                // Agregar datos del historial de compras desde la base de datos
                obtenerHistorialComprasDesdeBD(tablaHistorial);

                document.add(tablaHistorial);

            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                document.close();
            }
        }

        private void obtenerDatosCompraDesdeBD(PdfPTable tablaCompra) {
            MongoCollection coleccion = base.getCollection("Compras");
            MongoCursor<org.bson.Document> cursor = coleccion.find().cursor();
            while(cursor.hasNext()){
                org.bson.Document dato = cursor.next();
                PdfPCell celda = new PdfPCell();
                celda.setBackgroundColor(colorFondoCelda);
                celda.setHorizontalAlignment(Element.ALIGN_CENTER);
                celda.setVerticalAlignment(Element.ALIGN_MIDDLE);
                celda.setBorderColor(BaseColor.WHITE);

                String nombreProducto = dato.getString("nombre_producto");
                String lote = dato.getString("lote");
                String fechaIngreso = dato.getDate("fecha_ingreso").toString();
                int cantidad = dato.getInteger("cantidad_lote");

                celda.setPhrase(new Phrase(nombreProducto));
                tablaCompra.addCell(celda);

                celda.setPhrase(new Phrase(lote));
                tablaCompra.addCell(celda);

                celda.setPhrase(new Phrase(fechaIngreso));
                tablaCompra.addCell(celda);

                celda.setPhrase(new Phrase(String.valueOf(cantidad)));
                tablaCompra.addCell(celda);
            }
        }

        private void obtenerHistorialComprasDesdeBD(PdfPTable tablaHistorial) {
            MongoCollection coleccion = base.getCollection("Compras");
            MongoCursor<org.bson.Document> cursor = coleccion.find().cursor();
            while(cursor.hasNext()){
                org.bson.Document dato = cursor.next();
                PdfPCell celda = new PdfPCell();
                celda.setBackgroundColor(colorFondoCelda);
                celda.setHorizontalAlignment(Element.ALIGN_CENTER);
                celda.setVerticalAlignment(Element.ALIGN_MIDDLE);
                celda.setBorderColor(BaseColor.WHITE);

                String nombreProducto = dato.getString("nombre_producto");
                String fecha = dato.getDate("fecha_ingreso").toString();
                String lote = dato.getString("lote");
                String razon = dato.getString("razon_compra");
                int cantidad = dato.getInteger("cantidad_lote");

                celda.setPhrase(new Phrase(nombreProducto));
                tablaHistorial.addCell(celda);

                celda.setPhrase(new Phrase(fecha));
                tablaHistorial.addCell(celda);

                celda.setPhrase(new Phrase(lote));
                tablaHistorial.addCell(celda);

                celda.setPhrase(new Phrase(razon));
                tablaHistorial.addCell(celda);

                celda.setPhrase(new Phrase(String.valueOf(cantidad)));
                tablaHistorial.addCell(celda);
            }
        }
    }
