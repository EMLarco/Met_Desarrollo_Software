
package Modelo;

import Control.Conexion;
import com.mongodb.client.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import org.bson.Document;

public class VerProveedoresForm extends JFrame {
    private JTable table;
    
    Conexion con = new Conexion();
    MongoClient mongo = con.obtenerConexion();
    MongoDatabase base = mongo.getDatabase("SSCL");
    
    public VerProveedoresForm() {
        setTitle("Lista de Proveedores");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        // Crear un JPanel para contener los botones
        JPanel buttonPanel = new JPanel();
        JButton editarButton = new JButton("Editar");
        JButton eliminarButton = new JButton("Eliminar");

        // Agregar ActionListener para los botones de Editar y Eliminar
        editarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int filaSeleccionada = table.getSelectedRow();

                if (filaSeleccionada != -1) { // Verifica si se ha seleccionado una fila
                    // Obtén el ID del proveedor de la columna 0 de la fila seleccionada
                    String nombre = table.getValueAt(filaSeleccionada, 0).toString();

                    // Abre la ventana de EditarProveedorForm con el ID del proveedor seleccionado
                    SwingUtilities.invokeLater(() -> {
                        EditarProveedorForm editarProveedorForm = new EditarProveedorForm(nombre);
                        editarProveedorForm.setVisible(true);
                    });
                } else {
                    JOptionPane.showMessageDialog(VerProveedoresForm.this, "Por favor, seleccione un proveedor.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Agrega aquí la lógica para el botón "Eliminar"
            }
        });

        buttonPanel.add(editarButton);
        buttonPanel.add(eliminarButton);

        // Crear un modelo de tabla y configurarlo
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("ID");
        model.addColumn("Nombre");
        model.addColumn("Dirección");
        model.addColumn("Teléfono");
        model.addColumn("Email");
        model.addColumn("Tipo de Producto");
        model.addColumn("Sitio Web");

        table = new JTable(model);
        table.setBackground(Color.decode("#203B49"));
        table.setSelectionBackground(Color.decode("#FFA500"));

        // Llena la tabla con los datos de la base de datos
        cargarDatosProveedores();

        JScrollPane scrollPane = new JScrollPane(table);
        buttonPanel.setBackground(Color.decode("#203B49"));

        // Agrega el panel de botones y la tabla en un BorderLayout
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(buttonPanel, BorderLayout.NORTH);
        getContentPane().add(scrollPane, BorderLayout.CENTER);
    }

    // Método para cargar datos de proveedores desde la base de datos
    private void cargarDatosProveedores() {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        MongoCollection coleccion = base.getCollection("Proveedores");
        MongoCursor<Document> cursor = coleccion.find().cursor();
        while(cursor.hasNext()){
            Document dato = cursor.next();
            String nombre = dato.getString("nombre");
            String direccion = dato.getString("direccion");
            String telefono = dato.getString("telefono");
            String email = dato.getString("email");
            String tipoProducto = dato.getString("tipo_producto");
            String sitioWeb = dato.getString("sitio_web");

            // Agregar fila a la tabla
            model.addRow(new Object[]{nombre, direccion, telefono, email, tipoProducto, sitioWeb});
        }
    }

}
