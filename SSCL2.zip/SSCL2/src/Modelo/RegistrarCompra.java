package Modelo;

import Control.Conexion;
import com.mongodb.client.*;
import com.toedter.calendar.JDateChooser;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import org.bson.Document;

public class RegistrarCompra extends JFrame {
    private JPanel panel;
    public JTextField txtNombreProducto;
    public JTextField txtLote;
    public JTextField txtCantidadLote;
    public JTextField txtCapacidad;
    public JDateChooser dateChooserFechaIngreso;
    public JDateChooser dateChooserFechaCaducidad;
    public JTextField txtRazonCompra;
    public JTextField txtNumeroPaciente;
    
    Conexion con = new Conexion();
    MongoClient mongo = con.obtenerConexion();
    MongoDatabase base = mongo.getDatabase("SSCL");
    
    public RegistrarCompra() {
        setTitle("Registrar Compra");
        setSize(500, 600); // Aumenté la altura de la ventana
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        panel = new JPanel();
        panel.setLayout(new GridLayout(0, 2));
        panel.setBackground(Color.decode("#203B49"));

        JLabel lblNombreProducto = new JLabel("Nombre del Producto:");
        lblNombreProducto.setForeground(Color.WHITE);
        txtNombreProducto = new JTextField();

        JLabel lblLote = new JLabel("Lote:");
        lblLote.setForeground(Color.WHITE);
        txtLote = new JTextField();

        JLabel lblCantidadLote = new JLabel("Cantidad por Lote:");
        lblCantidadLote.setForeground(Color.WHITE);
        txtCantidadLote = new JTextField();

        JLabel lblCapacidad = new JLabel("Capacidad (ml):");
        lblCapacidad.setForeground(Color.WHITE);
        txtCapacidad = new JTextField();

        JLabel lblFechaIngreso = new JLabel("Fecha de Ingreso:");
        lblFechaIngreso.setForeground(Color.WHITE);
        dateChooserFechaIngreso = new JDateChooser();

        JLabel lblFechaCaducidad = new JLabel("Fecha de Caducidad:");
        lblFechaCaducidad.setForeground(Color.WHITE);
        dateChooserFechaCaducidad = new JDateChooser();

        JLabel lblRazonCompra = new JLabel("Razón de Compra:");
        lblRazonCompra.setForeground(Color.WHITE);
        txtRazonCompra = new JTextField();
        
        JLabel lblNumeroPaciente = new JLabel("Numero Celular:");
        lblNumeroPaciente.setForeground(Color.WHITE);
        txtNumeroPaciente = new JTextField();

        panel.add(lblNombreProducto);
        panel.add(txtNombreProducto);
        panel.add(lblLote);
        panel.add(txtLote);
        panel.add(lblCantidadLote);
        panel.add(txtCantidadLote);
        panel.add(lblCapacidad);
        panel.add(txtCapacidad);
        panel.add(lblFechaIngreso);
        panel.add(dateChooserFechaIngreso);
        panel.add(lblFechaCaducidad);
        panel.add(dateChooserFechaCaducidad);
        panel.add(lblRazonCompra);
        panel.add(txtRazonCompra);
        panel.add(lblNumeroPaciente);
        panel.add(txtNumeroPaciente);

        JButton btnGuardar = new JButton("Guardar");
        btnGuardar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                guardarCompra();
            }
        });

        panel.add(new JLabel());
        panel.add(btnGuardar);

        add(panel);
    }

public void guardarCompra() {

    String nombreProducto = txtNombreProducto.getText();
    String lote = txtLote.getText();
    int cantidadLote = Integer.parseInt(txtCantidadLote.getText());
    int capacidad = Integer.parseInt(txtCapacidad.getText());

    Date fechaIngreso = dateChooserFechaIngreso.getDate();
    Date fechaCaducidad = dateChooserFechaCaducidad.getDate();

    String razonCompra = txtRazonCompra.getText();
    
    String NumeroPaciente = txtNumeroPaciente.getText();
    
    MongoCollection<Document> coleccion = base.getCollection("Compras");
    Document insertar = new Document();
    insertar.append("nombre_producto", nombreProducto)
            .append("lote", lote).append("cantidad_lote", cantidadLote)
            .append("capacidad", capacidad)
            .append("fecha_ingreso", fechaIngreso)
            .append("fecha_caducidad", fechaCaducidad)
            .append("razon_compra", razonCompra)
            .append("numero_paciente", NumeroPaciente);
    coleccion.insertOne(insertar);
    JOptionPane.showMessageDialog(null, "Se ingreso correctamente a la base de datos");

    // Limpia los campos después de guardar
    txtNombreProducto.setText("");
    txtLote.setText("");
    txtCantidadLote.setText("");
    txtCapacidad.setText("");
    dateChooserFechaIngreso.setDate(null);
    dateChooserFechaCaducidad.setDate(null);
    txtRazonCompra.setText("");
    txtNumeroPaciente.setText("");
}

}
