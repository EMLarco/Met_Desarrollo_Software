package Modelo;

import Control.Conexion;
import com.mongodb.client.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import org.bson.Document;

public class RegistrarPacienteForm extends JFrame {
    
    Conexion con = new Conexion();
    MongoClient mongo = con.obtenerConexion();
    MongoDatabase base = mongo.getDatabase("SSCL");
    
    public RegistrarPacienteForm() {
        setSize(500, 600);
        JPanel contentPane = new JPanel(new BorderLayout());

        JPanel formPanel = new JPanel(new GridLayout(0, 2));
        formPanel.setBackground(Color.decode("#203B49")); // Color de fondo
        formPanel.setForeground(Color.WHITE); // Color de letra blanco

        Font timesNewRomanBold = new Font("Times New Roman", Font.BOLD, 18);
        Font timesNewRomanBold1 = new Font("Times New Roman", Font.BOLD, 24);

        // Campos para los datos del paciente
        JLabel pacienteLabel = new JLabel("Paciente:");
        pacienteLabel.setForeground(Color.WHITE); // Color de letra blanco
        formPanel.add(pacienteLabel);
        JTextField nombrePacienteField = new JTextField();
        nombrePacienteField.setForeground(Color.BLACK);
        formPanel.add(nombrePacienteField);

        JLabel segundoNombreLabel = new JLabel("Segundo Nombre:");
        segundoNombreLabel.setForeground(Color.WHITE); // Color de letra blanco
        formPanel.add(segundoNombreLabel);
        JTextField segundoNombreField = new JTextField();
        segundoNombreField.setForeground(Color.BLACK);
        formPanel.add(segundoNombreField);

        JLabel apellidoPacienteLabel = new JLabel("Apellido:");
        apellidoPacienteLabel.setForeground(Color.WHITE); // Color de letra blanco
        formPanel.add(apellidoPacienteLabel);
        JTextField apellidoPacienteField = new JTextField();
        apellidoPacienteField.setForeground(Color.BLACK);
        formPanel.add(apellidoPacienteField);

        // Campos para los datos del representante
        JLabel representanteLabel = new JLabel("Representante:");
        representanteLabel.setForeground(Color.WHITE); // Color de letra blanco
        formPanel.add(representanteLabel);
        JTextField nombreRepresentanteField = new JTextField();
        nombreRepresentanteField.setForeground(Color.BLACK);
        formPanel.add(nombreRepresentanteField);

        JLabel apellidoRepresentanteLabel = new JLabel("Apellido:");
        apellidoRepresentanteLabel.setForeground(Color.WHITE); // Color de letra blanco
        formPanel.add(apellidoRepresentanteLabel);
        JTextField apellidoRepresentanteField = new JTextField();
        apellidoRepresentanteField.setForeground(Color.BLACK);
        formPanel.add(apellidoRepresentanteField);

        JLabel parentezcoLabel = new JLabel("Parentezco:");
        parentezcoLabel.setForeground(Color.WHITE); // Color de letra blanco
        formPanel.add(parentezcoLabel);
        JTextField parentezcoField = new JTextField();
        parentezcoField.setForeground(Color.BLACK);
        formPanel.add(parentezcoField);

        // Campos para el contacto telefónico
        JLabel contactoLabel = new JLabel("Contacto Telefónico:");
        contactoLabel.setForeground(Color.WHITE); // Color de letra blanco
        formPanel.add(contactoLabel);
        JTextField codigoAreaField = new JTextField();
        codigoAreaField.setForeground(Color.BLACK);
        formPanel.add(codigoAreaField);

        JLabel numeroTelefonicoLabel = new JLabel("Número Telefónico:");
        numeroTelefonicoLabel.setForeground(Color.WHITE); // Color de letra blanco
        formPanel.add(numeroTelefonicoLabel);
        JTextField numeroTelefonicoField = new JTextField();
        numeroTelefonicoField.setForeground(Color.BLACK);
        formPanel.add(numeroTelefonicoField);

        // Campos para la residencia
        JLabel residenciaLabel = new JLabel("Residencia:");
        residenciaLabel.setForeground(Color.WHITE); // Color de letra blanco
        formPanel.add(residenciaLabel);
        JTextField direccionCalleField = new JTextField();
        direccionCalleField.setForeground(Color.BLACK);
        formPanel.add(direccionCalleField);

        JLabel direccionCalle2Label = new JLabel("Dirección Calle 2:");
        direccionCalle2Label.setForeground(Color.WHITE); // Color de letra blanco
        formPanel.add(direccionCalle2Label);
        JTextField direccionCalle2Field = new JTextField();
        direccionCalle2Field.setForeground(Color.BLACK);
        formPanel.add(direccionCalle2Field);

        JLabel ciudadLabel = new JLabel("Ciudad:");
        ciudadLabel.setForeground(Color.WHITE); // Color de letra blanco
        formPanel.add(ciudadLabel);
        JTextField ciudadField = new JTextField();
        ciudadField.setForeground(Color.BLACK);
        formPanel.add(ciudadField);

        JLabel estadoLabel = new JLabel("Estado/Provincia:");
        estadoLabel.setForeground(Color.WHITE); // Color de letra blanco
        formPanel.add(estadoLabel);
        JTextField estadoField = new JTextField();
        estadoField.setForeground(Color.BLACK);
        formPanel.add(estadoField);

        JLabel paisLabel = new JLabel("País:");
        paisLabel.setForeground(Color.WHITE); // Color de letra blanco
        formPanel.add(paisLabel);
        JTextField paisField = new JTextField();
        paisField.setForeground(Color.BLACK);
        formPanel.add(paisField);

        contentPane.add(formPanel, BorderLayout.CENTER);

        JButton guardarButton = new JButton("Guardar");
        guardarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Aquí puedes obtener los datos ingresados por el usuario
                String nombrePaciente = nombrePacienteField.getText();
                String segundoNombre = segundoNombreField.getText();
                String apellidoPaciente = apellidoPacienteField.getText();
                String nombreRepresentante = nombreRepresentanteField.getText();
                String apellidoRepresentante = apellidoRepresentanteField.getText();
                String parentezco = parentezcoField.getText();
                String codigoArea = codigoAreaField.getText();
                String numeroTelefonico = numeroTelefonicoField.getText();
                String direccionCalle = direccionCalleField.getText();
                String direccionCalle2 = direccionCalle2Field.getText();
                String ciudad = ciudadField.getText();
                String estado = estadoField.getText();
                String pais = paisField.getText();

                // Realizar la inserción en la base de datos
                
                MongoCollection<Document> coleccion = base.getCollection("Pacients");
                Document insertar = new Document();
                insertar.append("pac_nombre", nombrePaciente)
                        .append("pac_donombre", segundoNombre)
                        .append("pac_apellido", apellidoPaciente)
                        .append("rep_nombre", nombreRepresentante)
                        .append("rep_apellido", apellidoRepresentante)
                        .append("rep_parentezco", parentezco)
                        .append("con_numcel", numeroTelefonico)
                        .append("con_codearea", codigoArea)
                        .append("res_dire1", direccionCalle)
                        .append("res_dire2", direccionCalle2)
                        .append("res_ciu", ciudad)
                        .append("res_prov", estado)
                        .append("res_pais", pais);
                coleccion.insertOne(insertar);
                JOptionPane.showMessageDialog(null, "Datos guardados correctamente en la base de datos.");
            }
        });
        contentPane.add(guardarButton, BorderLayout.SOUTH);

        setLayout(new BorderLayout());
        add(contentPane);
    }
}
