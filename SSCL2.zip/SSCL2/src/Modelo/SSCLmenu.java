package Modelo;

import Control.Conexion;
import com.mongodb.client.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.table.DefaultTableModel;
import org.bson.Document;

public class SSCLmenu extends JFrame {
    Conexion con = new Conexion();
    MongoClient mongo = con.obtenerConexion();
    MongoDatabase base = mongo.getDatabase("SSCL");
    
    private JTabbedPane tabbedPane; // Panel de pestañas

    public SSCLmenu() {
        setTitle("Menú Principal");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         // Centra la ventana en la pantalla
        setLocationRelativeTo(null);

        JPanel contentPane = new JPanel(new BorderLayout());

        // Crear un panel para cada sección
        JPanel comprasPanel = createComprasPanel();
        JPanel inventarioPanel = createInventarioPanel();
        JPanel oficinaPanel = createOficinaPanel();

        // Crear el panel de pestañas y agregar las secciones como pestañas
        tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Compras - Proveedores", comprasPanel);
        tabbedPane.addTab("Inventario", inventarioPanel);
        tabbedPane.addTab("Oficina", oficinaPanel);

        contentPane.add(tabbedPane, BorderLayout.CENTER);
        
        

        setContentPane(contentPane);
    }

    private JPanel createComprasPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        panel.setBackground(Color.decode("#203B49"));
        int buttonWidth = 200; // Ancho deseado para los botones
        // Botón de "Registrar Compra" en la sección de Compras - Proveedores
    JButton registrarCompraButton = createCustomButton("Registrar Compra", "/imagen/compra.png");
        agregarImagenAlBoton(registrarCompraButton, "/imagen/compra.png");
        registrarCompraButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Abre la ventana de "Registrar Compra" y la coloca al lado derecho
                SwingUtilities.invokeLater(() -> {
                    RegistrarCompra registrarCompra = new RegistrarCompra();

                    // Obtén la ubicación actual de la ventana principal (SSCLmenu)
                    Point parentLocation = getLocation();

                    // Calcula la posición para la ventana "Registrar Compra"
                    int xOffset = getWidth(); // Desplazamiento horizontal
                    int yOffset = 0; // Desplazamiento vertical (ajusta según sea necesario)

                    // Configura la ubicación de la ventana "Registrar Compra"
                    registrarCompra.setLocation(parentLocation.x + xOffset, parentLocation.y + yOffset);
                    registrarCompra.setVisible(true);
                });
            }
        });
        registrarCompraButton.setPreferredSize(new Dimension(buttonWidth, registrarCompraButton.getPreferredSize().height));

        // Botón de "Registrar Proveedor" en la sección de Compras - Proveedores
        JButton registrarProveedorButton = createCustomButton("Registrar Proveedor", "/imagen/proveedor.png");
        agregarImagenAlBoton(registrarProveedorButton, "/imagen/proveedor.png");
        registrarProveedorButton.addActionListener(new ActionListener() {
                  @Override
                  public void actionPerformed(ActionEvent e) {
                      // Calcula la posición de la nueva ventana
                      Point parentLocation = getLocation();
                      int xOffset = getWidth(); // Desplazamiento horizontal

                      // Crea una nueva instancia de RegistroProveedorForm y configura la ubicación
                      SwingUtilities.invokeLater(() -> {
                          RegistroProveedorForm registroProveedorForm = new RegistroProveedorForm(SSCLmenu.this);
                          registroProveedorForm.setLocation(parentLocation.x + xOffset, parentLocation.y);
                          registroProveedorForm.setVisible(true);
                      });
                  }
              });
         registrarProveedorButton.setPreferredSize(new Dimension(buttonWidth, registrarProveedorButton.getPreferredSize().height));

        // Botón de "Historial de Compra" en la sección de Compras - Proveedores
        JButton historialCompraButton = createCustomButton("Historial de Compra", "/imagen/historialcompra.png");
        agregarImagenAlBoton(historialCompraButton, "/imagen/historialcompra.png");
        historialCompraButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Obtiene la ubicación actual de SSCLmenu
                Point parentLocation = getLocation();

                // Calcula la posición para la ventana HistorialCompra
                int xOffset = parentLocation.x + getWidth(); // Desplazamiento horizontal
                int yOffset = parentLocation.y; // Mantiene la misma posición vertical

                SwingUtilities.invokeLater(() -> {
                    HistorialCompra historialCompra = new HistorialCompra();

                    // Configura la ubicación de la ventana HistorialCompra
                    historialCompra.setLocation(xOffset, yOffset);
                    historialCompra.setVisible(true);
                });
            }
        });
        historialCompraButton.setPreferredSize(new Dimension(buttonWidth, historialCompraButton.getPreferredSize().height));

        // Botón de "Ver Proveedores" en la sección de Compras - Proveedores
         // Botón de "Ver Proveedores" en la sección de Compras - Proveedores
        JButton verProveedoresButton = createCustomButton("Ver Proveedores", "/imagen/verprovedor.png");
        agregarImagenAlBoton(verProveedoresButton, "/imagen/verprovedor.png");
        verProveedoresButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Abre la ventana de visualización de proveedores al hacer clic en el botón
                SwingUtilities.invokeLater(() -> {
                    VerProveedoresForm verProveedoresForm = new VerProveedoresForm();
                    verProveedoresForm.setVisible(true);
                });
            }
        });
        verProveedoresButton.setPreferredSize(new Dimension(buttonWidth, verProveedoresButton.getPreferredSize().height));


        // Botón de "Generar PDF de Compra" en la sección de Compras - Proveedores
        // Botón de "Generar PDF de Compra" en la sección de Compras - Proveedores
            JButton generarPDFCompraButton = createCustomButton("Generar PDF de Compra", "/imagen/generarpdf.png");
            agregarImagenAlBoton(generarPDFCompraButton, "/imagen/generarpdf.png");
            generarPDFCompraButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    SwingUtilities.invokeLater(() -> {
                        GenerarPDFCompraConHistorial mun = new GenerarPDFCompraConHistorial();
                        mun.generarPDFCompraConHistorial(); // Llama a la función para generar el PDF
                    });
                }
            });
            generarPDFCompraButton.setPreferredSize(new Dimension(buttonWidth, generarPDFCompraButton.getPreferredSize().height));

        // Botón de "Generar PDF de Proveedores" en la sección de Compras - Proveedores
        JButton generarPDFProveedoresButton = createCustomButton("Generar PDF de Proveedores", "/imagen/generarpdf.png");
        agregarImagenAlBoton(generarPDFProveedoresButton, "/imagen/generarpdf.png");
            generarPDFProveedoresButton.addActionListener(new ActionListener() {
              @Override
              public void actionPerformed(ActionEvent e) {
                  GenerarPDFProveedor mod = new GenerarPDFProveedor();
                  byte[] exito = mod.generarPDFComoBytes();

                  if (exito != null) {
                      // Si la generación fue exitosa, muestra un mensaje de éxito
                      JOptionPane.showMessageDialog(SSCLmenu.this, "PDF generado con éxito.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                  } else {
                      // Si hubo un error en la generación, muestra un mensaje de error
                      JOptionPane.showMessageDialog(SSCLmenu.this, "Error al generar el PDF.", "Error", JOptionPane.ERROR_MESSAGE);
                  }
              }
          });
        generarPDFProveedoresButton.setPreferredSize(new Dimension(buttonWidth, generarPDFProveedoresButton.getPreferredSize().height));

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(10, 10, 10, 10);
        panel.add(registrarCompraButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.insets = new Insets(10, 10, 10, 10);
        panel.add(registrarProveedorButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.insets = new Insets(10, 10, 10, 10);
        panel.add(historialCompraButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.insets = new Insets(10, 10, 10, 10);
        panel.add(verProveedoresButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.insets = new Insets(10, 10, 10, 10);
        panel.add(generarPDFCompraButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.insets = new Insets(10, 10, 10, 10);
        panel.add(generarPDFProveedoresButton, gbc);

        return panel;
    }

    
private JPanel createInventarioPanel() {
    JPanel panel = new JPanel(new BorderLayout());

    // Crear un panel para los botones en la parte superior
    JPanel buttonPanel = new JPanel();
    
    // Botón de "Registrar Uso"
 // Botón de "Registrar Uso"
JButton registrarUsoButton = new JButton("Registrar Uso");
registrarUsoButton.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        SwingUtilities.invokeLater(() -> {
            // Crea una instancia de la clase RegistrarUsoFarm
            RegistrarUsoFarm registrarUsoFarm = new RegistrarUsoFarm();

            // Obtiene la ubicación actual de la ventana principal (SSCLmenu)
            Point parentLocation = getLocation();

            // Calcula la posición para la ventana RegistrarUsoFarm
            int xOffset = getWidth(); // Desplazamiento horizontal
            int yOffset = 0; // Desplazamiento vertical (ajusta según sea necesario)

            // Configura la ubicación de la ventana RegistrarUsoFarm
            registrarUsoFarm.setLocation(parentLocation.x + xOffset, parentLocation.y + yOffset);
            registrarUsoFarm.setVisible(true);
        });
    }
});;
    
    // Botón de "Historial de Usos"
            JButton historialUsosButton = new JButton("Historial de Usos");
        historialUsosButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                SwingUtilities.invokeLater(() -> {
                    HistorialUsosFarm historialUsosFarm = new HistorialUsosFarm();
                    historialUsosFarm.setVisible(true);
                });
            }
        });
        DefaultTableModel tableModel = new DefaultTableModel();
        JTable table = new JTable(tableModel);
    // Botón de "Generar PDF"
    JButton generarPDFButton = new JButton("Generar PDF");
    generarPDFButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            SwingUtilities.invokeLater(() -> {
                GenerarPDFInv generarPDFInv = new GenerarPDFInv();
                generarPDFInv.generarPDFInventario(table); // Llama a la función para generar el PDF de inventario
            });
        }
    });
    // Agregar los botones al panel de botones
    buttonPanel.add(registrarUsoButton);
    buttonPanel.add(historialUsosButton);
    buttonPanel.add(generarPDFButton);
    
    // Agregar el panel de botones sobre la tabla
    panel.add(buttonPanel, BorderLayout.NORTH);

 

    // Agregar columnas a la tabla
    tableModel.addColumn("Producto");
    tableModel.addColumn("Cantidad");
    tableModel.addColumn("Lote");
    tableModel.addColumn("Capacidad");

    // Agregar la tabla a un JScrollPane para que tenga barras de desplazamiento si es necesario
    JScrollPane scrollPane = new JScrollPane(table);

    // Llenar la tabla desde la base de datos
    llenarTablaDesdeBD(tableModel);

    // Agregar la tabla al panel
    panel.add(scrollPane, BorderLayout.CENTER);

    return panel;
}

    
    private JButton createCustomButton(String text, String imagePath) {
        JButton button = new JButton(text);
        button.setVerticalTextPosition(SwingConstants.BOTTOM);
        button.setHorizontalTextPosition(SwingConstants.CENTER);

        ImageIcon icon = new ImageIcon(imagePath);
        Image scaledImage = icon.getImage().getScaledInstance(64, 64, Image.SCALE_SMOOTH);
        button.setIcon(new ImageIcon(scaledImage));

        return button;
    }


    private JPanel createOficinaPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        panel.setBackground(Color.decode("#203B49"));
        int buttonWidth = 200;

        // Botón de "Registrar Paciente" en la sección de Oficina
        JButton registrarPacienteButton = new JButton("Registrar Paciente");
        agregarImagenAlBoton(registrarPacienteButton, "/imagen/regpaciente.png"); // Reemplaza con la ruta correcta

        registrarPacienteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Abre la ventana de RegistrarPacienteForm al hacer clic en el botón
                SwingUtilities.invokeLater(() -> {
                    RegistrarPacienteForm pacienteForm = new RegistrarPacienteForm();
                    pacienteForm.setVisible(true);
                });
            }
        });
        registrarPacienteButton.setPreferredSize(new Dimension(buttonWidth, registrarPacienteButton.getPreferredSize().height));


        // Botón de "Buscar Paciente" en la sección de Oficina
        JButton buscarPacienteButton = new JButton("Buscar Paciente");
        agregarImagenAlBoton(buscarPacienteButton, "/imagen/buspaciente.png"); // Reemplaza con la ruta correcta

        buscarPacienteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Abre la ventana de BuscarPacienteForm al hacer clic en el botón
                SwingUtilities.invokeLater(() -> {
                    BuscarPacienteForm buscarPacienteForm = new BuscarPacienteForm();
                    buscarPacienteForm.setVisible(true);
                });
            }
        });
        buscarPacienteButton.setPreferredSize(new Dimension(buttonWidth, buscarPacienteButton.getPreferredSize().height));


        // Botón de "Ver Pacientes" en la sección de Oficina
        JButton verPacientesButton = new JButton("Ver Pacientes");
        agregarImagenAlBoton(verPacientesButton, "/imagen/verpaciente.png"); // Reemplaza con la ruta correcta

        verPacientesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Abre la ventana de VerPacientesForm al hacer clic en el botón
                SwingUtilities.invokeLater(() -> {
                    VerPacientesForm verPacientesForm = new VerPacientesForm();
                    verPacientesForm.setVisible(true);
                });
            }
        });
        verPacientesButton.setPreferredSize(new Dimension(buttonWidth, verPacientesButton.getPreferredSize().height));

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(10, 10, 10, 10);
        panel.add(registrarPacienteButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.insets = new Insets(10, 10, 10, 10);
        panel.add(buscarPacienteButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.insets = new Insets(10, 10, 10, 10);
        panel.add(verPacientesButton, gbc);

        panel.add(new JLabel("Oficina Section"), gbc);
        return panel;
    }

    // Método para agregar una imagen a un botón
    private void agregarImagenAlBoton(JButton button, String rutaImagen) {
        try {
            Image img = ImageIO.read(getClass().getResource(rutaImagen));
            img = img.getScaledInstance(32, 32, Image.SCALE_SMOOTH);
            button.setIcon(new ImageIcon(img));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    

    private void llenarTablaDesdeBD(DefaultTableModel tableModel) {
        MongoCollection coleccion = base.getCollection("Compras");
        MongoCursor<Document> cursor = coleccion.find().cursor();
        tableModel.setRowCount(0);
        while(cursor.hasNext()){
            Document datos=cursor.next();
            String producto = datos.getString("nombre_producto");
            int cantidad = datos.getInteger("cantidad_lote");
            String lote = datos.getString("lote");
            String capacidad = datos.getInteger("capacidad").toString();

            // Agregar una fila a la tabla con los datos de la consulta
            tableModel.addRow(new Object[]{producto, cantidad, lote, capacidad});
        }
    }

    
    
}
