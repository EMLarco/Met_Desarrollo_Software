
package Modelo;

import Control.Conexion;
import com.mongodb.client.*;
import com.toedter.calendar.JCalendar;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import org.bson.Document;

public class RegistrarUsoFarm extends JFrame {
    private JCalendar calendar;
    
    Conexion con = new Conexion();
    MongoClient mongo = con.obtenerConexion();
    MongoDatabase base = mongo.getDatabase("SSCL");
    
    public RegistrarUsoFarm() {
        setTitle("Registrar Uso");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel contentPane = new JPanel(new BorderLayout());

        JPanel formPanel = new JPanel(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(5, 5, 5, 5);

        // Etiquetas
        JLabel lblSolicitante = new JLabel("Nombre del Solicitante:");
        JLabel lblMedicamento = new JLabel("Medicamento:");
        JLabel lblMlUsar = new JLabel("Ml a Usar:");
        JLabel lblPaciente = new JLabel("Paciente:");
        JLabel lblZonaTrabajada = new JLabel("Zona Trabajada:");
        JLabel lblFechaUso = new JLabel("Fecha de Uso:");
        JLabel lblRazonUso = new JLabel("Razón de Uso:");

        // Campos de entrada
        JTextField txtSolicitante = new JTextField(20);
        JTextField txtMedicamento = new JTextField(20);
        JTextField txtMlUsar = new JTextField(20);
        JTextField txtPaciente = new JTextField(20);
        JTextField txtZonaTrabajada = new JTextField(20);
        JTextField txtFechaUso = new JTextField(20);
        JTextArea txtRazonUso = new JTextArea(5, 20);
        txtRazonUso.setLineWrap(true);

        // Botón para guardar el registro
        JButton btnGuardar = new JButton("Guardar");

        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(lblSolicitante, gbc);

        gbc.gridx = 1;
        gbc.gridy = 0;
        formPanel.add(txtSolicitante, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(lblMedicamento, gbc);

        gbc.gridx = 1;
        gbc.gridy = 1;
        formPanel.add(txtMedicamento, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(lblMlUsar, gbc);

        gbc.gridx = 1;
        gbc.gridy = 2;
        formPanel.add(txtMlUsar, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        formPanel.add(lblPaciente, gbc);

        gbc.gridx = 1;
        gbc.gridy = 3;
        formPanel.add(txtPaciente, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        formPanel.add(lblZonaTrabajada, gbc);

        gbc.gridx = 1;
        gbc.gridy = 4;
        formPanel.add(txtZonaTrabajada, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        formPanel.add(lblFechaUso, gbc);

        gbc.gridx = 1;
        gbc.gridy = 5;
        formPanel.add(txtFechaUso, gbc);

        gbc.gridx = 0;
        gbc.gridy = 6;
        formPanel.add(lblRazonUso, gbc);

        gbc.gridx = 1;
        gbc.gridy = 6;
        formPanel.add(new JScrollPane(txtRazonUso), gbc);

        gbc.gridx = 0;
        gbc.gridy = 7;
        gbc.gridwidth = 2;
        formPanel.add(btnGuardar, gbc);

        contentPane.add(formPanel, BorderLayout.CENTER);

        setContentPane(contentPane);;

        // Agrega un ActionListener al botón para manejar el guardado de la información
         btnGuardar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Date selectedDate = calendar.getDate();
                String medicamento = txtMedicamento.getText();
                String mlUsar = txtMlUsar.getText();
                String nombreSolicitante = txtSolicitante.getText(); // Corregir aquí

                // Obtener la capacidad actual del medicamento desde la base de datos de compras
                int capacidadActual = obtenerCapacidadDesdeBD(medicamento);

                // Restar la cantidad a usar (mlUsar) de la capacidad actual
                int mlUsarInt = Integer.parseInt(mlUsar);
                int nuevaCapacidad = capacidadActual - mlUsarInt;

                // Actualizar la capacidad en la base de datos de compras
                actualizarCapacidadEnBD(medicamento, nuevaCapacidad);

                // Guardar mlUsar en la base de datos de inventario
                guardarUsoEnInventario(selectedDate, medicamento, mlUsar);

                // Guardar todos los datos en la base de datos farmacéutica
                guardarEnBaseDeDatosFarmaceutica(selectedDate, medicamento, mlUsar, nombreSolicitante, txtPaciente.getText(), txtZonaTrabajada.getText(), txtRazonUso.getText());

                JOptionPane.showMessageDialog(RegistrarUsoFarm.this, "Datos guardados en la base de datos.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            }
        });
    }


    public int obtenerCapacidadDesdeBD(String medicamento) {
        MongoCollection coleccion = base.getCollection("Compras");
        MongoCursor<Document> cursor = coleccion.find(new Document("medicamento",medicamento)).cursor();
        int capacidadActual = 0;
        try{
            Document dato = cursor.next();
            capacidadActual=dato.getInteger("capacidad");
            
        }catch(Exception e){
            
        }
        return capacidadActual;
    }

    private void actualizarCapacidadEnBD(String medicamento, int nuevaCapacidad) {
        MongoCollection coleccion = base.getCollection("Compras");
        String capacidad=String.valueOf(obtenerCapacidadDesdeBD(medicamento));
        Document antiguo = new Document();
        antiguo.append("medicamento", medicamento).append("capacidad",  capacidad);
        Document nuevo = new Document();
        nuevo.append("medicamento", medicamento).append("capacidad", nuevaCapacidad);
        Document update = new Document("$set",nuevo);
        coleccion.updateOne(antiguo, update);
    }

    private void guardarUsoEnInventario(Date fechaUso, String medicamento, String mlUsar) {
        MongoCollection coleccion = base.getCollection("Inventario");
        Document dato = new Document();
        dato.append("fecha_uso", fechaUso.getTime())
                .append("medicamento", medicamento)
                .append("ml_usar", mlUsar);
        coleccion.insertOne(dato);
    }
    
    
    private void guardarEnBaseDeDatosFarmaceutica(Date fechaUso, String medicamento, String mlUsar, String nombreSolicitante, String paciente, String zonaTrabajada, String razonUso) {
        MongoCollection coleccion = base.getCollection("Farmaceutica");
        Document dato = new Document();
        dato.append("fecha_uso", fechaUso)
                .append("medicamento", medicamento)
                .append("ml_usar", mlUsar)
                .append("nombre_solicitante", nombreSolicitante)
                .append("paciente", paciente)
                .append("zona_trabajada", zonaTrabajada)
                .append("razon_uso", razonUso);
        coleccion.insertOne(dato);
    }

}