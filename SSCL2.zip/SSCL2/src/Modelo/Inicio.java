
package Modelo;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.RoundRectangle2D;
import javax.swing.border.Border;

public class Inicio {
    public void menu() {
        SwingUtilities.invokeLater(() -> {
        // Crear un nuevo JFrame
        JFrame frame = new JFrame("");
        frame.setSize(500, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Crear un JPanel personalizado para el fondo
        JPanel fondoPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Cargar la imagen de fondo
                ImageIcon imageIcon = new ImageIcon(getClass().getResource("/imagen/logo.png")); // Asegúrate de que la imagen esté en el mismo directorio que tu clase
                Image image = imageIcon.getImage();
                // Dibujar la imagen de fondo
                g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
            }
        };
        fondoPanel.setLayout(null);
        
                // Función para crear un borde redondeado
        Border bordeRedondeado = new Border() {
            int radio = 15; // Ajusta el radio según tu preferencia

            @Override
            public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
                g.setColor(Color.decode("#829DAE")); // Color del borde
                ((Graphics2D) g).draw(new RoundRectangle2D.Double(x, y, width - 1, height - 1, radio, radio));
            }

            @Override
            public Insets getBorderInsets(Component c) {
                return new Insets(radio, radio, radio, radio);
            }

            @Override
            public boolean isBorderOpaque() {
                return false;
            }
        };
        
        Font timesNewRomanBold = new Font("Times New Roman", Font.BOLD, 18);
        Font timesNewRomanBold1 = new Font("Times New Roman", Font.BOLD, 24);

        // Botón "Admin"
        JButton btnAdmin = new JButton("Administrador");
        btnAdmin.setBounds(140, 210, 200, 40);
        btnAdmin.setBackground(Color.decode("#829DAE"));
        btnAdmin.setFont(timesNewRomanBold1);
        btnAdmin.setBorder(bordeRedondeado); // Aplicar borde redondeado

        // Botón "Salir"
        JButton btnSalir = new JButton("Salir");
        btnSalir.setBounds(175, 268, 127, 27);
        btnSalir.setBackground(Color.decode("#829DAE"));
        btnSalir.setFont(timesNewRomanBold);
        btnSalir.setBorder(bordeRedondeado); // Aplicar borde redondeado

        // Agregar los botones al panel de fondo
        fondoPanel.add(btnAdmin);
        fondoPanel.add(btnSalir);
        
        btnAdmin.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Cerrar la ventana actual
                    frame.dispose();
                    // Abrir la ventana de login (VentanaLogin)
                    MenAdmin ventanaLogin = new MenAdmin();
                    ventanaLogin.setVisible(true);
                }
            });

        // Agregar el panel de fondo al JFrame
        frame.setContentPane(fondoPanel);
        
        frame.setLocationRelativeTo(null);
        
        
        // Manejar el clic en el botón "Salir"
        btnSalir.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Cerrar el programa
                    System.exit(0);
                }
            });

        // Hacer visible el JFrame
        frame.setVisible(true);
        
        });
    }
}




