
package Modelo;

import Control.Conexion;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.FileOutputStream;
import com.itextpdf.text.Font; // Importar la clase Font de iText
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.mongodb.client.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VerPacientesForm extends JFrame {
    private DefaultTableModel tableModel;
    private JButton editarButton;
    private JButton eliminarButton;
    private JTable table;
    
    Conexion con = new Conexion();
    MongoClient mongo = con.obtenerConexion();
    MongoDatabase base = mongo.getDatabase("SSCL");
    
    public VerPacientesForm() {
        setTitle("Ver Pacientes");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel contentPane = new JPanel(new BorderLayout());
        contentPane.setBackground(Color.decode("#203B49"));

        // Crear botones para editar y eliminar
        editarButton = new JButton("Editar");
        eliminarButton = new JButton("Eliminar");

       
       // Agregar un ActionListener para el botón "Editar"
        editarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Lógica para editar el paciente seleccionado
                int filaSeleccionada = table.getSelectedRow();
                if (filaSeleccionada >= 0) {
                    String nombre = tableModel.getValueAt(filaSeleccionada, 0).toString();
                    abrirVentanaEdicion(nombre); // Abre la ventana de edición con el ID del paciente
                }
            }
        });

        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Lógica para eliminar el paciente seleccionado
                int filaSeleccionada = table.getSelectedRow();
                if (filaSeleccionada >= 0) {
                    String nombre = tableModel.getValueAt(filaSeleccionada, 0).toString();
                    
                    // Implementa la lógica de eliminación aquí, por ejemplo:
                    if (eliminarPaciente(nombre)) {
                        // Recargar los datos de la tabla
                        tableModel.setRowCount(0);
                        fillTableWithData();
                    }
                }
            }
        });

        // Crear una tabla para mostrar los pacientes
        tableModel = new DefaultTableModel();
        table = new JTable(tableModel);
        table.setBackground(Color.decode("#203B49"));
        table.setForeground(Color.WHITE);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBackground(Color.WHITE);

        // Configurar las columnas de la tabla
        tableModel.addColumn("ID");
        tableModel.addColumn("Nombre");
        tableModel.addColumn("Apellido");
        tableModel.addColumn("Representante");
        tableModel.addColumn("Contacto");

        // Llenar la tabla con datos de la base de datos (debes ajustar la conexión)
        fillTableWithData();

      // Agregar botones en la parte superior
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(Color.decode("#203B49"));
        buttonPanel.add(editarButton);
        buttonPanel.add(eliminarButton);

        contentPane.add(buttonPanel, BorderLayout.NORTH);
        contentPane.add(scrollPane, BorderLayout.CENTER);

       
    

        // Agregar botón para generar PDF
        JButton generarPDFButton = new JButton("Generar PDF");
        generarPDFButton.addActionListener(e -> generarPDFPacientes());
        contentPane.add(generarPDFButton, BorderLayout.SOUTH);

        setContentPane(contentPane);
    }

  // Método para llenar la tabla con datos de la base de datos
    private void fillTableWithData() {
        MongoCollection coleccion = base.getCollection("Pacients");
        MongoCursor<org.bson.Document> cursor = coleccion.find().cursor();
        while(cursor.hasNext()){
            org.bson.Document dato=cursor.next();
            String nombre = dato.getString("pac_nombre");
            String apellido = dato.getString("pac_apellido");
            String representante = dato.getString("rep_nombre");
            String contacto = dato.getString("con_numcel");

            // Agregar una fila a la tabla con los datos del paciente
            tableModel.addRow(new Object[]{nombre, apellido, representante, contacto});
        }
    }
    
    // Método para generar un PDF con la lista de pacientes
    private void generarPDFPacientes() {
        Document document = new Document();
        try {
            PdfWriter.getInstance(document, new FileOutputStream("lista_pacientes.pdf"));

            // Definir estilos de fuente y formato
            Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 24, BaseColor.WHITE);
            Font headerFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12, BaseColor.WHITE);
            Font cellFont = FontFactory.getFont(FontFactory.HELVETICA, 10, BaseColor.BLACK);

            document.open();

            // Agregar un título al documento
            Paragraph title = new Paragraph("Lista de Pacientes", titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            title.setSpacingAfter(20);
            document.add(title);

            // Crea una tabla para mostrar los datos de los pacientes
            PdfPTable table = new PdfPTable(5);
            table.setWidthPercentage(100);

            // Configurar anchos de columnas
            float[] columnWidths = {1, 3, 3, 3, 3};
            table.setWidths(columnWidths);

            // Agregar encabezados de columna a la tabla
            PdfPCell cell;
            cell = new PdfPCell(new com.itextpdf.text.Phrase("ID", headerFont)); // Calificar con com.itextpdf.text
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setBackgroundColor(new BaseColor(32, 59, 73));
            table.addCell(cell);

            cell = new PdfPCell(new com.itextpdf.text.Phrase("Nombre", headerFont)); // Calificar con com.itextpdf.text
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setBackgroundColor(new BaseColor(32, 59, 73));
            table.addCell(cell);

            cell = new PdfPCell(new com.itextpdf.text.Phrase("Apellido", headerFont)); // Calificar con com.itextpdf.text
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setBackgroundColor(new BaseColor(32, 59, 73));
            table.addCell(cell);

            cell = new PdfPCell(new com.itextpdf.text.Phrase("Representante", headerFont)); // Calificar con com.itextpdf.text
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setBackgroundColor(new BaseColor(32, 59, 73));
            table.addCell(cell);

            cell = new PdfPCell(new com.itextpdf.text.Phrase("Contacto", headerFont)); // Calificar con com.itextpdf.text
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setBackgroundColor(new BaseColor(32, 59, 73));
            table.addCell(cell);

            // Llena la tabla con datos de la base de datos (para el PDF)
            fillTableWithDataForPDF(table);

            document.add(table);

            document.close();
            JOptionPane.showMessageDialog(this, "Lista de pacientes exportada como lista_pacientes.pdf", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Método para llenar la tabla con datos de la base de datos (para el PDF)
    private void fillTableWithDataForPDF(PdfPTable table) {
        MongoCollection coleccion = base.getCollection("Pacients");
        MongoCursor<org.bson.Document> cursor = coleccion.find().cursor();
        while(cursor.hasNext()){
            org.bson.Document dato=cursor.next();
            String nombre = dato.getString("pac_nombre");
            String apellido = dato.getString("pac_apellido");
            String representante = dato.getString("rep_nombre");
            String contacto = dato.getString("con_numcel");
            
            PdfPCell cell;

            cell = new PdfPCell(new com.itextpdf.text.Phrase(nombre)); // Calificar con com.itextpdf.text
            cell.setHorizontalAlignment(Element.ALIGN_LEFT);
            table.addCell(cell);

            cell = new PdfPCell(new com.itextpdf.text.Phrase(apellido)); // Calificar con com.itextpdf.text
            cell.setHorizontalAlignment(Element.ALIGN_LEFT);
            table.addCell(cell);

            cell = new PdfPCell(new com.itextpdf.text.Phrase(representante)); // Calificar con com.itextpdf.text
            cell.setHorizontalAlignment(Element.ALIGN_LEFT);
            table.addCell(cell);

            cell = new PdfPCell(new com.itextpdf.text.Phrase(contacto)); // Calificar con com.itextpdf.text
            cell.setHorizontalAlignment(Element.ALIGN_LEFT);
            table.addCell(cell);
        }
    }
    
        // Método para eliminar un paciente por nombre
    private boolean eliminarPaciente(String nombre) {
        MongoCollection coleccion = base.getCollection("Pacients");
        MongoCursor<org.bson.Document> cursor = coleccion.find(new org.bson.Document("pac_nombre",nombre)).cursor();
        try{
            org.bson.Document dato = cursor.next();
            coleccion.deleteOne(dato);
            return true;
        }catch(Exception e){
            
        }
        return false;
    }
    
    

    // Agregar un método para abrir la ventana de edición
private void abrirVentanaEdicion(String nombre) {
    SwingUtilities.invokeLater(() -> {
        // Crea una ventana de edición con el ID del paciente
        EditarPacienteForm editarPacienteForm = new EditarPacienteForm(nombre);
        editarPacienteForm.setVisible(true);
    });
}
}
