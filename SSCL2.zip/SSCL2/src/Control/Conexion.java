package Control;

import com.mongodb.client.*;

public class Conexion {
    
   MongoClient mongo=null;
   String mongoLocal = "mongodb://localhost:27017";
   String mongoNube = "";
    //Método para obtener una instancia de la conexión
    public MongoClient obtenerConexion() {
        try {
            mongo=MongoClients.create(mongoLocal);
            System.out.println("Conectado a Mongo");
            return mongo;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    //Método para cerrar la conexión
    public void cerrarConexion() {
        if(mongo==null){
            mongo.close();
        }
    }
}
