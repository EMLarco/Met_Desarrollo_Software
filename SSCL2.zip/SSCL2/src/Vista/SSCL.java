
package Vista;

import Modelo.*;

public class SSCL {

    public static void main(String[] args) {
  
        Inicio start= new Inicio();
        start.menu();
        
    }
}
